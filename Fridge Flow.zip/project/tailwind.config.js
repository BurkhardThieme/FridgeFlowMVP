module.exports = {
  content: [
    "./src/**/*.{html,js,ts,jsx,tsx}",
    "app/**/*.{ts,tsx}",
    "components/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        // Fridge Flow Brand Colors - basierend auf dem Logo
        "fridge-blue": {
          50: "#f0f8ff",
          100: "#e0f2fe", 
          200: "#bae6fd",
          300: "#7dd3fc",
          400: "#38bdf8",
          500: "#0ea5e9", // Hauptblau aus dem Logo
          600: "#0284c7", // Dunkleres Blau für Buttons
          700: "#0369a1",
          800: "#075985",
          900: "#0c4a6e",
        },
        "fridge-green": {
          50: "#f0fdf4",
          100: "#dcfce7",
          200: "#bbf7d0", 
          300: "#86efac",
          400: "#4ade80",
          500: "#22c55e", // Hauptgrün aus dem Logo
          600: "#16a34a", // Dunkleres Grün für Akzente
          700: "#15803d",
          800: "#166534",
          900: "#14532d",
        },
        "fridge-navy": {
          50: "#f8fafc",
          100: "#f1f5f9",
          200: "#e2e8f0",
          300: "#cbd5e1", 
          400: "#94a3b8",
          500: "#64748b",
          600: "#475569",
          700: "#334155", // Dunkles Blau aus dem Logo Text
          800: "#1e293b",
          900: "#0f172a",
        },
        // Legacy colors für Kompatibilität
        "colour-styleslabel-colour": "var(--colour-styleslabel-colour)",
        "colour-stylesneutral-colourblack":
          "var(--colour-stylesneutral-colourblack)",
        "colour-stylesneutral-colourgray-4":
          "var(--colour-stylesneutral-colourgray-4)",
        "colour-stylesneutral-colourwhite":
          "var(--colour-stylesneutral-colourwhite)",
        "colour-stylesprimary-colourprimary-100":
          "var(--colour-stylesprimary-colourprimary-100)",
        "colour-stylesprimary-colourprimary-80":
          "var(--colour-stylesprimary-colourprimary-80)",
        "food-recipedark-grey": "var(--food-recipedark-grey)",
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
      },
      fontFamily: {
        "text-style-medium-text-bold":
          "var(--text-style-medium-text-bold-font-family)",
        "text-style-small-text-bold":
          "var(--text-style-small-text-bold-font-family)",
        "text-style-smaller-text-bold":
          "var(--text-style-smaller-text-bold-font-family)",
        "text-style-smaller-text-regular":
          "var(--text-style-smaller-text-regular-font-family)",
        "text-style-smaller-text-semi-bold":
          "var(--text-style-smaller-text-semi-bold-font-family)",
        sans: [
          "ui-sans-serif",
          "system-ui",
          "sans-serif",
          '"Apple Color Emoji"',
          '"Segoe UI Emoji"',
          '"Segoe UI Symbol"',
          '"Noto Color Emoji"',
        ],
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      keyframes: {
        "accordion-down": {
          from: { height: "0" },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: "0" },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
      },
    },
    container: { center: true, padding: "2rem", screens: { "2xl": "1400px" } },
  },
  plugins: [],
  darkMode: ["class"],
};
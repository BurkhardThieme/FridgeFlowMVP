export interface FoodItem {
  id: string;
  name: string;
  quantity: string;
  unit: string;
  expiryDate: Date;
  category: string;
  image?: string;
  addedDate: Date;
  isExpiringSoon: boolean;
}

export interface Recipe {
  id: string;
  name: string;
  ingredients: string[];
  instructions: string[];
  image?: string;
  cookingTime: number;
  difficulty: 'easy' | 'medium' | 'hard';
}

export interface ShoppingItem {
  id: string;
  name: string;
  quantity: string;
  unit: string;
  category: string;
  isCompleted: boolean;
}

export type NavigationTab = 'home' | 'recipes' | 'shopping' | 'account';
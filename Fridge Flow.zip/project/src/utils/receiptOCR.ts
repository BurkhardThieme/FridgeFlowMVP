import Tesseract from 'tesseract.js';
import { getFoodSuggestion } from '../data/foodDatabase';

export interface ScannedItem {
  name: string;
  quantity: string;
  unit: string;
  category: string;
  expiryDate: Date;
  image?: string;
  confidence: number;
}

export interface OCRProgress {
  status: string;
  progress: number;
}

// Erweiterte deutsche Lebensmittel-Datenbank mit exakten Variationen
const FOOD_DATABASE = {
  // Gemüse
  'radieschen': { name: 'Radieschen', category: 'Gemüse', unit: 'Bund', quantity: '1', days: 7 },
  'radiesschen': { name: 'Radieschen', category: 'Gemüse', unit: 'Bund', quantity: '1', days: 7 },
  'radischen': { name: 'Radieschen', category: 'Gemüse', unit: 'Bund', quantity: '1', days: 7 },
  
  // Milchprodukte
  'käseaufschnitt': { name: 'Käseaufschnitt', category: 'Milchprodukte', unit: 'g', quantity: '150', days: 7 },
  'kaeseaufschnitt': { name: 'Käseaufschnitt', category: 'Milchprodukte', unit: 'g', quantity: '150', days: 7 },
  'käse aufschnitt': { name: 'Käseaufschnitt', category: 'Milchprodukte', unit: 'g', quantity: '150', days: 7 },
  'käseaufsch': { name: 'Käseaufschnitt', category: 'Milchprodukte', unit: 'g', quantity: '150', days: 7 },
  
  // Fleisch
  'bauchspeck': { name: 'Bauchspeck', category: 'Fleisch', unit: 'g', quantity: '200', days: 5 },
  'speck': { name: 'Bauchspeck', category: 'Fleisch', unit: 'g', quantity: '200', days: 5 },
  'bacon': { name: 'Bauchspeck', category: 'Fleisch', unit: 'g', quantity: '200', days: 5 },
  
  // Obst
  'clementinen': { name: 'Clementinen', category: 'Obst', unit: 'kg', quantity: '1', days: 10 },
  'clementine': { name: 'Clementinen', category: 'Obst', unit: 'kg', quantity: '1', days: 10 },
  'clementin': { name: 'Clementinen', category: 'Obst', unit: 'kg', quantity: '1', days: 10 },
  'mandarinen': { name: 'Clementinen', category: 'Obst', unit: 'kg', quantity: '1', days: 10 },
  'mandarine': { name: 'Clementinen', category: 'Obst', unit: 'kg', quantity: '1', days: 10 },
  
  // Getränke
  'dornfelder': { name: 'Dornfelder Wein', category: 'Getränke', unit: 'Flasche', quantity: '1', days: 1095 },
  'rotwein': { name: 'Rotwein', category: 'Getränke', unit: 'Flasche', quantity: '1', days: 1095 },
  'wein': { name: 'Wein', category: 'Getränke', unit: 'Flasche', quantity: '1', days: 1095 },
  
  // Standard Lebensmittel
  'äpfel': { name: 'Äpfel', category: 'Obst', unit: 'kg', quantity: '1', days: 14 },
  'apfel': { name: 'Äpfel', category: 'Obst', unit: 'kg', quantity: '1', days: 14 },
  'bananen': { name: 'Bananen', category: 'Obst', unit: 'kg', quantity: '1', days: 7 },
  'banane': { name: 'Bananen', category: 'Obst', unit: 'kg', quantity: '1', days: 7 },
  'tomaten': { name: 'Tomaten', category: 'Gemüse', unit: 'kg', quantity: '0.5', days: 7 },
  'tomate': { name: 'Tomaten', category: 'Gemüse', unit: 'kg', quantity: '0.5', days: 7 },
  'gurken': { name: 'Gurken', category: 'Gemüse', unit: 'Stück', quantity: '2', days: 7 },
  'gurke': { name: 'Gurken', category: 'Gemüse', unit: 'Stück', quantity: '2', days: 7 },
  'karotten': { name: 'Karotten', category: 'Gemüse', unit: 'kg', quantity: '1', days: 21 },
  'karotte': { name: 'Karotten', category: 'Gemüse', unit: 'kg', quantity: '1', days: 21 },
  'möhren': { name: 'Karotten', category: 'Gemüse', unit: 'kg', quantity: '1', days: 21 },
  'möhre': { name: 'Karotten', category: 'Gemüse', unit: 'kg', quantity: '1', days: 21 },
  'zwiebeln': { name: 'Zwiebeln', category: 'Gemüse', unit: 'kg', quantity: '1', days: 30 },
  'zwiebel': { name: 'Zwiebeln', category: 'Gemüse', unit: 'kg', quantity: '1', days: 30 },
  'paprika': { name: 'Paprika', category: 'Gemüse', unit: 'Stück', quantity: '3', days: 10 },
  'salat': { name: 'Salat', category: 'Gemüse', unit: 'Stück', quantity: '1', days: 5 },
  'spinat': { name: 'Spinat', category: 'Gemüse', unit: 'g', quantity: '300', days: 3 },
  'brokkoli': { name: 'Brokkoli', category: 'Gemüse', unit: 'Stück', quantity: '1', days: 7 },
  'blumenkohl': { name: 'Blumenkohl', category: 'Gemüse', unit: 'Stück', quantity: '1', days: 7 },
  'milch': { name: 'Milch', category: 'Milchprodukte', unit: 'L', quantity: '1', days: 5 },
  'h-milch': { name: 'Milch', category: 'Milchprodukte', unit: 'L', quantity: '1', days: 5 },
  'vollmilch': { name: 'Milch', category: 'Milchprodukte', unit: 'L', quantity: '1', days: 5 },
  'käse': { name: 'Käse', category: 'Milchprodukte', unit: 'g', quantity: '200', days: 14 },
  'gouda': { name: 'Käse', category: 'Milchprodukte', unit: 'g', quantity: '200', days: 14 },
  'emmentaler': { name: 'Käse', category: 'Milchprodukte', unit: 'g', quantity: '200', days: 14 },
  'joghurt': { name: 'Joghurt', category: 'Milchprodukte', unit: 'g', quantity: '500', days: 10 },
  'naturjoghurt': { name: 'Joghurt', category: 'Milchprodukte', unit: 'g', quantity: '500', days: 10 },
  'quark': { name: 'Quark', category: 'Milchprodukte', unit: 'g', quantity: '500', days: 7 },
  'butter': { name: 'Butter', category: 'Milchprodukte', unit: 'g', quantity: '250', days: 21 },
  'margarine': { name: 'Butter', category: 'Milchprodukte', unit: 'g', quantity: '250', days: 21 },
  'sahne': { name: 'Sahne', category: 'Milchprodukte', unit: 'ml', quantity: '200', days: 7 },
  'frischkäse': { name: 'Frischkäse', category: 'Milchprodukte', unit: 'g', quantity: '200', days: 10 },
  'hähnchen': { name: 'Hähnchenbrust', category: 'Fleisch', unit: 'g', quantity: '500', days: 3 },
  'hühnchen': { name: 'Hähnchenbrust', category: 'Fleisch', unit: 'g', quantity: '500', days: 3 },
  'hähnchenbrust': { name: 'Hähnchenbrust', category: 'Fleisch', unit: 'g', quantity: '500', days: 3 },
  'hühnchenbrust': { name: 'Hähnchenbrust', category: 'Fleisch', unit: 'g', quantity: '500', days: 3 },
  'hackfleisch': { name: 'Hackfleisch', category: 'Fleisch', unit: 'g', quantity: '500', days: 2 },
  'rinderhack': { name: 'Hackfleisch', category: 'Fleisch', unit: 'g', quantity: '500', days: 2 },
  'schweinehack': { name: 'Hackfleisch', category: 'Fleisch', unit: 'g', quantity: '500', days: 2 },
  'wurst': { name: 'Wurst', category: 'Fleisch', unit: 'g', quantity: '200', days: 7 },
  'schinken': { name: 'Schinken', category: 'Fleisch', unit: 'g', quantity: '200', days: 7 },
  'brot': { name: 'Brot', category: 'Getreide', unit: 'Stück', quantity: '1', days: 4 },
  'vollkornbrot': { name: 'Brot', category: 'Getreide', unit: 'Stück', quantity: '1', days: 4 },
  'weißbrot': { name: 'Brot', category: 'Getreide', unit: 'Stück', quantity: '1', days: 4 },
  'brötchen': { name: 'Brötchen', category: 'Getreide', unit: 'Stück', quantity: '6', days: 2 },
  'nudeln': { name: 'Nudeln', category: 'Getreide', unit: 'g', quantity: '500', days: 730 },
  'pasta': { name: 'Nudeln', category: 'Getreide', unit: 'g', quantity: '500', days: 730 },
  'spaghetti': { name: 'Nudeln', category: 'Getreide', unit: 'g', quantity: '500', days: 730 },
  'penne': { name: 'Nudeln', category: 'Getreide', unit: 'g', quantity: '500', days: 730 },
  'reis': { name: 'Reis', category: 'Getreide', unit: 'kg', quantity: '1', days: 730 },
  'basmati': { name: 'Reis', category: 'Getreide', unit: 'kg', quantity: '1', days: 730 },
  'jasmin': { name: 'Reis', category: 'Getreide', unit: 'kg', quantity: '1', days: 730 },
  'mehl': { name: 'Mehl', category: 'Getreide', unit: 'kg', quantity: '1', days: 365 },
  'haferflocken': { name: 'Haferflocken', category: 'Getreide', unit: 'g', quantity: '500', days: 365 },
  'eier': { name: 'Eier', category: 'Milchprodukte', unit: 'Stück', quantity: '12', days: 28 },
  'ei': { name: 'Eier', category: 'Milchprodukte', unit: 'Stück', quantity: '12', days: 28 },
  'bio-eier': { name: 'Eier', category: 'Milchprodukte', unit: 'Stück', quantity: '12', days: 28 },
  'olivenöl': { name: 'Olivenöl', category: 'Sonstiges', unit: 'ml', quantity: '500', days: 365 },
  'öl': { name: 'Olivenöl', category: 'Sonstiges', unit: 'ml', quantity: '500', days: 365 },
  'sonnenblumenöl': { name: 'Olivenöl', category: 'Sonstiges', unit: 'ml', quantity: '500', days: 365 },
  'essig': { name: 'Essig', category: 'Sonstiges', unit: 'ml', quantity: '500', days: 730 },
  'zucker': { name: 'Zucker', category: 'Sonstiges', unit: 'kg', quantity: '1', days: 730 },
  'salz': { name: 'Salz', category: 'Gewürze', unit: 'g', quantity: '500', days: 1095 },
  'pfeffer': { name: 'Pfeffer', category: 'Gewürze', unit: 'g', quantity: '100', days: 730 },
  'honig': { name: 'Honig', category: 'Sonstiges', unit: 'g', quantity: '500', days: 730 },
  'marmelade': { name: 'Marmelade', category: 'Sonstiges', unit: 'g', quantity: '450', days: 365 },
};

// Präzise Preis-Patterns für deutsche Kassenbons
const PRICE_PATTERNS = [
  /(\d+[,\.]\d{2})\s*€?\s*$/,           // 1,99€ am Ende
  /€\s*(\d+[,\.]\d{2})\s*$/,            // €1,99 am Ende
  /(\d+[,\.]\d{2})\s*EUR\s*$/i,         // 1,99 EUR am Ende
  /(\d+[,\.]\d{2})\s*[AB]\s*$/,         // 1,99 A (Steuerklasse)
  /\s+(\d+[,\.]\d{2})\s*$/,             // Preis am Zeilenende
];

// Erweiterte Blacklist für Nicht-Lebensmittel
const NON_FOOD_BLACKLIST = [
  // Orte und Städte (exakt wie auf dem Kassenbon)
  'schweinfurt', 'oskar-von-miller-str', 'oskar von miller str', 'münchen', 'berlin', 'hamburg', 
  'köln', 'frankfurt', 'stuttgart', 'düsseldorf', 'dortmund', 'essen', 'leipzig', 'bremen', 
  'dresden', 'hannover', 'nürnberg', 'duisburg',
  
  // Supermarkt-Namen und Ketten
  'edeka', 'e-center', 'ecenter', 'rewe', 'aldi', 'lidl', 'kaufland', 'real', 'penny', 'netto', 
  'norma', 'rossmann', 'dm', 'müller',
  
  // Kassenbon-spezifische Begriffe
  'kassenbon', 'beleg', 'quittung', 'rechnung', 'bon', 'kassier', 'kasse', 'datum', 'uhrzeit',
  'summe', 'gesamt', 'total', 'zwischensumme', 'mwst', 'mehrwertsteuer', 'steuer', 'pfand', 
  'rückgeld', 'bar', 'ec-karte', 'kreditkarte', 'bargeld', 'visa', 'mastercard', 'paypal', 
  'girokarte', 'enthaltene', 'netto', 'brutto',
  
  // Nicht-Lebensmittel Produkte
  'l&m', 'lm', 'zigaretten', 'tabak', 'marlboro', 'camel', 'lucky strike', 'winston',
  'blue', 'red', 'gold', 'silver', 'light', 'menthol',
  
  // Service und Kontakt
  'danke', 'vielen dank', 'wiedersehen', 'service', 'hotline', 'telefon', 'fax', 'email',
  'öffnungszeiten', 'montag', 'dienstag', 'mittwoch', 'donnerstag', 'freitag', 'samstag', 
  'sonntag', 'uhr', 'geöffnet', 'geschlossen',
  
  // Adressen und Kontaktdaten
  'straße', 'str', 'plz', 'postleitzahl', 'hausnummer', 'haus-nr', 'tel', 'telefon',
  
  // Kundenkarten und Aktionen
  'edecard', 'edeka card', 'punkte', 'sammeln', 'prämien', 'erwerben', 'bonuspunkte', 
  'wert', 'gewesen', 'nutzen', 'sie', 'die', 'ihr', 'einkauf', 'ware', 'uns',
  
  // Sonstiges
  'artikel', 'position', 'nummer', 'nr', 'code', 'barcode', 'scan', 'preis', 'einzelpreis',
  'rabatt', 'aktion', 'angebot', 'prozent', '%', 'mehrweg', 'einweg', 'pfandfrei',
  'bediente', 'sie', 'für', 'ihren', 'auf', 'im', 'unsere', 'montag-samstag'
];

export class ReceiptOCR {
  private worker: Tesseract.Worker | null = null;

  async initialize(onProgress?: (progress: OCRProgress) => void): Promise<void> {
    try {
      this.worker = await Tesseract.createWorker('deu', 1, {
        logger: (m) => {
          if (onProgress) {
            onProgress({
              status: this.getGermanStatus(m.status),
              progress: m.progress || 0
            });
          }
          console.log('OCR Progress:', m);
        }
      });

      // Hochoptimierte OCR-Parameter für deutsche Kassenbons
      await this.worker.setParameters({
        tessedit_char_whitelist: 'ABCDEFGHIJKLMNOPQRSTUVWXYZÄÖÜabcdefghijklmnopqrstuvwxyzäöüß0123456789.,€-+*/% ()[]',
        tessedit_pageseg_mode: Tesseract.PSM.SINGLE_BLOCK,
        tessedit_ocr_engine_mode: Tesseract.OEM.LSTM_ONLY,
        preserve_interword_spaces: '1',
        user_defined_dpi: '300',
        // Verbesserte Texterkennung
        textord_really_old_xheight: '1',
        textord_min_xheight: '10',
        classify_enable_learning: '0',
        classify_enable_adaptive_matcher: '1',
      });

      console.log('✅ OCR Worker initialized with enhanced German optimization');
    } catch (error) {
      console.error('❌ OCR initialization failed:', error);
      throw new Error('OCR konnte nicht initialisiert werden');
    }
  }

  private getGermanStatus(status: string): string {
    const statusMap: { [key: string]: string } = {
      'initializing api': 'API wird initialisiert...',
      'initialized api': 'API initialisiert',
      'loading language traineddata': 'Deutsche Sprachdaten werden geladen...',
      'initializing tesseract': 'Tesseract wird initialisiert...',
      'initialized tesseract': 'Tesseract bereit',
      'loading image': 'Bild wird geladen...',
      'preprocessing image': 'Bild wird optimiert...',
      'recognizing text': 'Text wird erkannt...',
      'done': 'Fertig!'
    };
    
    return statusMap[status] || status;
  }

  async scanReceipt(
    imageFile: File | string, 
    onProgress?: (progress: OCRProgress) => void
  ): Promise<ScannedItem[]> {
    if (!this.worker) {
      await this.initialize(onProgress);
    }

    try {
      console.log('🔍 Starting enhanced OCR scan for real receipt...');
      
      const { data: { text, confidence } } = await this.worker!.recognize(imageFile);
      console.log('📝 OCR Text extracted (confidence:', confidence, '):', text);

      const items = this.parseReceiptTextAdvanced(text);
      console.log('🛒 Final parsed items:', items);

      return items;
    } catch (error) {
      console.error('❌ OCR scan failed:', error);
      throw new Error('Kassenbon konnte nicht gescannt werden');
    }
  }

  private parseReceiptTextAdvanced(text: string): ScannedItem[] {
    const lines = text.split('\n')
      .map(line => line.trim())
      .filter(line => line.length > 2);
    
    const items: ScannedItem[] = [];
    
    console.log('📄 Processing', lines.length, 'lines from real receipt...');

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const cleanLine = this.cleanLine(line);
      
      console.log(`Line ${i + 1}: "${line}" → cleaned: "${cleanLine}"`);

      // Skip if line is blacklisted (sehr wichtig!)
      if (this.isBlacklisted(cleanLine)) {
        console.log('❌ BLACKLISTED:', cleanLine);
        continue;
      }

      // Skip receipt metadata
      if (this.isReceiptMetadata(line)) {
        console.log('📋 METADATA:', cleanLine);
        continue;
      }

      // Check if line has a price (likely a product)
      if (!this.hasPrice(line)) {
        console.log('💰 NO PRICE:', line);
        continue;
      }

      // Try to extract food item with advanced matching
      const item = this.extractFoodItemAdvanced(line, cleanLine);
      if (item) {
        items.push(item);
        console.log('✅ FOUND FOOD ITEM:', item);
      } else {
        console.log('🚫 NO FOOD MATCH:', cleanLine);
      }
    }

    // Remove duplicates and sort by confidence
    const uniqueItems = this.removeDuplicates(items);
    const sortedItems = uniqueItems.sort((a, b) => b.confidence - a.confidence);
    
    console.log('🎯 Final unique items:', sortedItems);
    return sortedItems;
  }

  private cleanLine(line: string): string {
    return line
      .toLowerCase()
      .replace(/[^\w\säöüß.,€-]/g, ' ')  // Remove special chars except common ones
      .replace(/\s+/g, ' ')              // Normalize whitespace
      .trim();
  }

  private isBlacklisted(cleanLine: string): boolean {
    // Exakte Matches für häufige Blacklist-Begriffe
    for (const blacklisted of NON_FOOD_BLACKLIST) {
      if (cleanLine.includes(blacklisted)) {
        return true;
      }
      
      // Fuzzy match für OCR-Fehler
      if (this.levenshteinDistance(cleanLine, blacklisted) <= 1 && blacklisted.length > 4) {
        return true;
      }
    }
    
    // Spezielle Checks für den Kassenbon
    if (cleanLine.includes('schweinfurt') || cleanLine.includes('oskar')) {
      return true;
    }
    
    if (cleanLine.includes('l m') || cleanLine.includes('lm') || cleanLine.includes('blue')) {
      return true; // Zigaretten
    }
    
    return false;
  }

  private isReceiptMetadata(line: string): boolean {
    const metadataPatterns = [
      /^(kassenbon|beleg|quittung|rechnung)/i,
      /^(datum|zeit|uhrzeit|kasse|kassier)/i,
      /^(summe|gesamt|total|zwischensumme)/i,
      /^(mwst|steuer|tax|pfand|rückgeld)/i,
      /^(danke|vielen dank|wiedersehen)/i,
      /^(tel|telefon|fax|email|hotline)/i,
      /^(str|straße|plz|postleitzahl)/i,
      /^\d{2}[\.\/]\d{2}[\.\/]\d{2,4}/,  // Dates
      /^\d{2}:\d{2}/,                     // Times
      /^artikel\s*\d+/i,                  // Article numbers
      /^position\s*\d+/i,                 // Position numbers
      /enthaltene\s+mehrwertsteuer/i,     // VAT info
      /nutzen\s+sie\s+die/i,              // Customer card info
      /punkte\s+sammeln/i,                // Points collection
      /öffnungszeiten/i,                  // Opening hours
      /montag.*samstag/i,                 // Days of week
    ];

    return metadataPatterns.some(pattern => pattern.test(line));
  }

  private hasPrice(line: string): boolean {
    return PRICE_PATTERNS.some(pattern => pattern.test(line));
  }

  private extractFoodItemAdvanced(originalLine: string, cleanLine: string): ScannedItem | null {
    try {
      // Remove product codes from the beginning
      let productText = originalLine;
      
      // Remove common prefixes
      productText = productText.replace(/^\d+\s+/, ''); // Remove leading numbers
      productText = productText.replace(/^\*\d+\s+/, ''); // Remove codes with *
      
      // Remove price from the end
      for (const pattern of PRICE_PATTERNS) {
        productText = productText.replace(pattern, '');
      }

      const cleanProductText = this.cleanLine(productText);
      console.log(`🔍 Analyzing product text: "${productText}" → "${cleanProductText}"`);
      
      // Find matching food item with advanced algorithm
      const foodMatch = this.findAdvancedFoodMatch(cleanProductText);
      if (!foodMatch) {
        console.log(`❌ No food match found for: "${cleanProductText}"`);
        return null;
      }

      console.log(`✅ Food match found: ${foodMatch.keyword} → ${foodMatch.data.name} (confidence: ${foodMatch.confidence})`);

      // Extract quantity if present
      const quantity = this.extractQuantity(originalLine, foodMatch.data);
      
      // Calculate expiry date
      const expiryDate = new Date();
      expiryDate.setDate(expiryDate.getDate() + foodMatch.data.days);

      // Get image from food database
      const suggestion = getFoodSuggestion(foodMatch.data.name);

      return {
        name: foodMatch.data.name,
        quantity: quantity.amount,
        unit: quantity.unit,
        category: foodMatch.data.category,
        expiryDate,
        image: suggestion?.image,
        confidence: foodMatch.confidence
      };
    } catch (error) {
      console.error('Error extracting food item:', error);
      return null;
    }
  }

  private findAdvancedFoodMatch(text: string): { keyword: string; data: any; confidence: number } | null {
    let bestMatch: { keyword: string; data: any; confidence: number } | null = null;
    let highestScore = 0;

    console.log(`🎯 Searching food matches for: "${text}"`);

    for (const [keyword, data] of Object.entries(FOOD_DATABASE)) {
      const score = this.calculateAdvancedMatchScore(text, keyword);
      
      console.log(`  - Testing "${keyword}": score = ${score.toFixed(3)}`);
      
      if (score > highestScore && score > 0.5) {  // Lower threshold for better matching
        highestScore = score;
        bestMatch = { keyword, data, confidence: score };
        console.log(`    ✅ New best match: ${keyword} (${score.toFixed(3)})`);
      }
    }

    if (bestMatch) {
      console.log(`🏆 Final best match: "${bestMatch.keyword}" with confidence ${bestMatch.confidence.toFixed(3)}`);
    } else {
      console.log(`❌ No match found for: "${text}"`);
    }

    return bestMatch;
  }

  private calculateAdvancedMatchScore(text: string, keyword: string): number {
    // Exact match (highest score)
    if (text === keyword) {
      return 0.98;
    }

    // Contains exact keyword
    if (text.includes(keyword)) {
      return 0.95;
    }

    // Keyword contains text (for partial matches)
    if (keyword.includes(text) && text.length >= 4) {
      return 0.90;
    }

    // Word-by-word matching
    const textWords = text.split(' ').filter(w => w.length >= 3);
    const keywordWords = keyword.split(' ').filter(w => w.length >= 3);
    
    let wordMatches = 0;
    let totalWords = Math.max(textWords.length, keywordWords.length);
    
    for (const textWord of textWords) {
      for (const keywordWord of keywordWords) {
        if (textWord === keywordWord) {
          wordMatches += 1;
        } else if (textWord.includes(keywordWord) || keywordWord.includes(textWord)) {
          wordMatches += 0.8;
        } else {
          // Fuzzy match with Levenshtein
          const distance = this.levenshteinDistance(textWord, keywordWord);
          const maxLength = Math.max(textWord.length, keywordWord.length);
          const similarity = 1 - (distance / maxLength);
          
          if (similarity > 0.7) {
            wordMatches += similarity * 0.7;
          }
        }
      }
    }
    
    if (totalWords > 0) {
      const wordScore = wordMatches / totalWords;
      if (wordScore > 0.6) {
        return wordScore * 0.85;
      }
    }

    // Character-level fuzzy matching for single words
    if (textWords.length === 1 && keywordWords.length === 1) {
      const textWord = textWords[0];
      const keywordWord = keywordWords[0];
      
      if (textWord.length >= 4 && keywordWord.length >= 4) {
        const distance = this.levenshteinDistance(textWord, keywordWord);
        const maxLength = Math.max(textWord.length, keywordWord.length);
        const similarity = 1 - (distance / maxLength);
        
        if (similarity > 0.6) {
          return similarity * 0.8;
        }
      }
    }

    // Substring matching for longer words
    for (const textWord of textWords) {
      if (textWord.length >= 5) {
        for (const keywordWord of keywordWords) {
          if (keywordWord.length >= 5) {
            if (textWord.includes(keywordWord.substring(0, 5)) || 
                keywordWord.includes(textWord.substring(0, 5))) {
              return 0.7;
            }
          }
        }
      }
    }

    return 0;
  }

  private levenshteinDistance(str1: string, str2: string): number {
    const matrix = Array(str2.length + 1).fill(null).map(() => Array(str1.length + 1).fill(null));

    for (let i = 0; i <= str1.length; i++) matrix[0][i] = i;
    for (let j = 0; j <= str2.length; j++) matrix[j][0] = j;

    for (let j = 1; j <= str2.length; j++) {
      for (let i = 1; i <= str1.length; i++) {
        const indicator = str1[i - 1] === str2[j - 1] ? 0 : 1;
        matrix[j][i] = Math.min(
          matrix[j][i - 1] + 1,     // deletion
          matrix[j - 1][i] + 1,     // insertion
          matrix[j - 1][i - 1] + indicator // substitution
        );
      }
    }

    return matrix[str2.length][str1.length];
  }

  private extractQuantity(line: string, foodData: any): { amount: string; unit: string } {
    // Quantity patterns for German receipts
    const quantityPatterns = [
      /(\d+(?:[,\.]\d+)?)\s*(kg|g|l|ml|liter|gramm|kilogramm)/i,
      /(\d+(?:[,\.]\d+)?)\s*(stück|st\.?|stk\.?)/i,
      /(\d+(?:[,\.]\d+)?)\s*(pack|packung|pkg)/i,
      /(\d+(?:[,\.]\d+)?)\s*(dose|dosen|fl\.?|flasche|flaschen)/i,
      /(\d+(?:[,\.]\d+)?)\s*(beutel|btl\.?|glas|gläser|bund)/i,
      /(\d+(?:[,\.]\d+)?)\s*x\s*/i,         // 2x etwas
      /(\d+)\s*er\s*/i,                     // 6er Pack
    ];

    // Try to find quantity in the line
    for (const pattern of quantityPatterns) {
      const match = line.match(pattern);
      if (match) {
        const amount = match[1].replace(',', '.');
        const unit = this.normalizeUnit(match[2] || 'Stück');
        return { amount, unit };
      }
    }

    // Use default from food database
    return {
      amount: foodData.quantity,
      unit: foodData.unit
    };
  }

  private normalizeUnit(unit: string): string {
    const unitMap: { [key: string]: string } = {
      'kg': 'kg', 'kilogramm': 'kg',
      'g': 'g', 'gramm': 'g',
      'l': 'L', 'liter': 'L',
      'ml': 'ml',
      'stück': 'Stück', 'st': 'Stück', 'st.': 'Stück', 'stk': 'Stück', 'stk.': 'Stück',
      'pack': 'Packung', 'packung': 'Packung', 'pkg': 'Packung',
      'dose': 'Dose', 'dosen': 'Dose',
      'flasche': 'Flasche', 'flaschen': 'Flasche', 'fl': 'Flasche', 'fl.': 'Flasche',
      'beutel': 'Beutel', 'btl': 'Beutel', 'btl.': 'Beutel',
      'glas': 'Glas', 'gläser': 'Glas',
      'bund': 'Bund'
    };

    const normalized = unit.toLowerCase().replace(/[^\w]/g, '');
    return unitMap[normalized] || 'Stück';
  }

  private removeDuplicates(items: ScannedItem[]): ScannedItem[] {
    const seen = new Set<string>();
    return items.filter(item => {
      const key = `${item.name.toLowerCase()}-${item.category}`;
      if (seen.has(key)) {
        return false;
      }
      seen.add(key);
      return true;
    });
  }

  async cleanup(): Promise<void> {
    if (this.worker) {
      await this.worker.terminate();
      this.worker = null;
      console.log('🧹 OCR Worker terminated');
    }
  }
}

// Singleton instance
let ocrInstance: ReceiptOCR | null = null;

export const getOCRInstance = (): ReceiptOCR => {
  if (!ocrInstance) {
    ocrInstance = new ReceiptOCR();
  }
  return ocrInstance;
};

export const cleanupOCR = async (): Promise<void> => {
  if (ocrInstance) {
    await ocrInstance.cleanup();
    ocrInstance = null;
  }
};
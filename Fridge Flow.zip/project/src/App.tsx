import React, { useState } from 'react';
import { Navigation } from './components/Navigation';
import { HomeScreen } from './screens/HomeScreen';
import { RecipesScreen } from './screens/RecipesScreen';
import { ShoppingScreen } from './screens/ShoppingScreen';
import { AccountScreen } from './screens/AccountScreen';
import { NavigationTab } from './types';

function App() {
  const [activeTab, setActiveTab] = useState<NavigationTab>('home');
  const [recipeFilters, setRecipeFilters] = useState<string[]>([]);
  const [showShoppingConfirmation, setShowShoppingConfirmation] = useState(false);

  const renderScreen = () => {
    switch (activeTab) {
      case 'home':
        return <HomeScreen onNavigateToRecipes={handleNavigateToRecipes} />;
      case 'recipes':
        return <RecipesScreen highlightedIngredients={recipeFilters} />;
      case 'shopping':
        return <ShoppingScreen />;
      case 'account':
        return <AccountScreen />;
      default:
        return <HomeScreen onNavigateToRecipes={handleNavigateToRecipes} />;
    }
  };

  const handleNavigateToRecipes = (ingredients: string[]) => {
    setRecipeFilters(ingredients);
    setActiveTab('recipes');
  };

  // Auto-navigate to shopping list when items are added from recipes
  React.useEffect(() => {
    const handleShoppingListUpdate = () => {
      if (activeTab === 'recipes') {
        setShowShoppingConfirmation(true);
        setTimeout(() => {
          setActiveTab('shopping');
          setShowShoppingConfirmation(false);
        }, 1500);
      }
    };

    // Listen for shopping list updates
    window.addEventListener('shoppingListUpdated', handleShoppingListUpdate);
    
    return () => {
      window.removeEventListener('shoppingListUpdated', handleShoppingListUpdate);
    };
  }, [activeTab]);

  return (
    <div className="h-screen bg-gray-50 flex flex-col overflow-hidden">
      {/* Shopping confirmation overlay */}
      {showShoppingConfirmation && (
        <div className="absolute inset-0 bg-black/50 z-50 flex items-center justify-center">
          <div className="bg-white rounded-3xl p-8 mx-4 text-center shadow-2xl">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl">✅</span>
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">
              Zur Einkaufsliste hinzugefügt!
            </h3>
            <p className="text-gray-600">
              Weiterleitung zur Einkaufsliste...
            </p>
          </div>
        </div>
      )}

      <div className="flex-1 overflow-hidden">
        {renderScreen()}
      </div>
      <Navigation activeTab={activeTab} onTabChange={setActiveTab} />
    </div>
  );
}

export default App;
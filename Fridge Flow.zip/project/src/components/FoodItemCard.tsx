import React from 'react';
import { FoodItem } from '../types';
import { Button } from './ui/button';
import { Trash2 } from 'lucide-react';

interface FoodItemCardProps {
  item: FoodItem;
  onDelete: (id: string) => void;
  onAddToShopping: (item: FoodItem) => void;
  onConsume: (item: FoodItem) => void;
}

export const FoodItemCard: React.FC<FoodItemCardProps> = ({
  item,
  onDelete,
  onAddToShopping,
  onConsume,
}) => {
  const getDaysUntilExpiry = () => {
    const today = new Date();
    const expiry = new Date(item.expiryDate);
    const diffTime = expiry.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const daysLeft = getDaysUntilExpiry();
  const isExpired = daysLeft < 0;
  const isExpiringSoon = daysLeft <= 3 && daysLeft >= 0;

  const getExpiryColor = () => {
    if (isExpired) return 'text-red-600 bg-red-100 border-red-200';
    if (isExpiringSoon) return 'text-orange-600 bg-orange-100 border-orange-200';
    return 'text-green-600 bg-green-100 border-green-200';
  };

  const getExpiryText = () => {
    if (isExpired) return 'Abgelaufen';
    if (isExpiringSoon) return `${daysLeft} Tag${daysLeft !== 1 ? 'e' : ''}`;
    return `${daysLeft} Tage`;
  };

  const getCardBorderColor = () => {
    if (isExpired) return 'border-red-200 hover:border-red-300';
    if (isExpiringSoon) return 'border-orange-200 hover:border-orange-300';
    return 'border-gray-200 hover:border-green-300';
  };

  const handleCardClick = (e: React.MouseEvent) => {
    // Prevent card click when clicking on action buttons
    if ((e.target as HTMLElement).closest('button')) {
      return;
    }
    onConsume(item);
  };

  return (
    <div 
      onClick={handleCardClick}
      className={`bg-white/90 backdrop-blur-sm rounded-2xl p-4 shadow-lg hover:shadow-xl border-2 ${getCardBorderColor()} active:scale-98 transition-all duration-200 cursor-pointer`}
    >
      <div className="flex items-center space-x-3">
        {/* Product Image */}
        <div className="w-16 h-16 rounded-xl overflow-hidden bg-gray-100 flex-shrink-0 shadow-md">
          {item.image ? (
            <img
              src={item.image}
              alt={item.name}
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-gray-200 to-gray-300 flex items-center justify-center">
              <span className="text-gray-400">📦</span>
            </div>
          )}
        </div>
        
        {/* Product Info */}
        <div className="flex-1 min-w-0">
          <h3 className="font-bold text-gray-900 truncate text-lg mb-1">
            {item.name}
          </h3>
          <p className="text-sm text-gray-600 font-medium">
            {item.quantity} {item.unit} • {item.category}
          </p>
        </div>

        {/* Expiry and Actions */}
        <div className="flex flex-col items-end space-y-2">
          <div className={`px-3 py-1 rounded-xl text-xs font-bold border ${getExpiryColor()}`}>
            {getExpiryText()}
          </div>
          
          <div className="flex space-x-1">
            <Button
              size="sm"
              variant="ghost"
              onClick={(e) => {
                e.stopPropagation();
                onDelete(item.id);
              }}
              className="w-8 h-8 p-0 rounded-xl bg-red-100 hover:bg-red-200 text-red-600 hover:text-red-700 shadow-sm"
              title="Löschen"
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
      
      {/* Kompakter Hinweis */}
      <div className="mt-3 text-center">
        <div className="inline-flex items-center px-3 py-1 bg-gray-100 rounded-xl">
          <span className="text-xs text-gray-600 font-medium">👆 Tippen zum Verbrauchen</span>
        </div>
      </div>
    </div>
  );
};
import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { FoodAutocomplete } from './FoodAutocomplete';
import { FoodItem } from '../types';
import { getFoodSuggestion, FoodSuggestion } from '../data/foodDatabase';
import { Calendar, Package, Sparkles } from 'lucide-react';

interface AddItemDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (item: Omit<FoodItem, 'id' | 'addedDate' | 'isExpiringSoon'>) => void;
}

const categories = [
  'Obst',
  'Gemüse',
  'Milchprodukte',
  'Fleisch',
  'Fisch',
  'Getreide',
  'Gewürze',
  'Getränke',
  'Süßwaren',
  'Sonstiges',
];

const units = [
  'g',
  'kg', 
  'ml',
  'L',
  'Stück',
  'Packung',
  'Dose',
  'Flasche',
  'Beutel',
  'Glas'
];

// Quick add presets for common items
const quickAddPresets = [
  { name: 'Milch', quantity: '1', unit: 'L', category: 'Milchprodukte', days: 5 },
  { name: 'Brot', quantity: '1', unit: 'Stück', category: 'Getreide', days: 3 },
  { name: 'Eier', quantity: '12', unit: 'Stück', category: 'Milchprodukte', days: 21 },
  { name: 'Äpfel', quantity: '1', unit: 'kg', category: 'Obst', days: 7 },
  { name: 'Joghurt', quantity: '500', unit: 'g', category: 'Milchprodukte', days: 7 },
  { name: 'Käse', quantity: '200', unit: 'g', category: 'Milchprodukte', days: 14 },
];

export const AddItemDialog: React.FC<AddItemDialogProps> = ({
  isOpen,
  onClose,
  onAdd,
}) => {
  const [formData, setFormData] = useState({
    name: '',
    quantity: '',
    unit: 'g',
    category: 'Sonstiges',
    expiryDate: '',
    image: '',
  });

  const [showQuickAdd, setShowQuickAdd] = useState(true);
  const [useAutocomplete, setUseAutocomplete] = useState(true);

  // Initialize form data when dialog opens
  useEffect(() => {
    if (isOpen) {
      // Reset form for new item
      setFormData({
        name: '',
        quantity: '',
        unit: 'g',
        category: 'Sonstiges',
        expiryDate: '',
        image: '',
      });
      setShowQuickAdd(true);
      setUseAutocomplete(true);
    }
  }, [isOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.quantity || !formData.expiryDate) {
      return;
    }

    const itemData = {
      name: formData.name,
      quantity: formData.quantity,
      unit: formData.unit,
      category: formData.category,
      expiryDate: new Date(formData.expiryDate),
      image: formData.image || undefined,
    };

    onAdd(itemData);
    handleClose();
  };

  const handleQuickAdd = (preset: typeof quickAddPresets[0]) => {
    const expiryDate = new Date();
    expiryDate.setDate(expiryDate.getDate() + preset.days);
    
    setFormData({
      name: preset.name,
      quantity: preset.quantity,
      unit: preset.unit,
      category: preset.category,
      expiryDate: expiryDate.toISOString().split('T')[0],
      image: '',
    });
    setShowQuickAdd(false);
    setUseAutocomplete(false);
  };

  const handleSuggestionSelect = (suggestion: FoodSuggestion) => {
    const expiryDate = new Date();
    expiryDate.setDate(expiryDate.getDate() + suggestion.defaultExpiryDays);
    
    setFormData({
      name: suggestion.name,
      quantity: suggestion.defaultQuantity,
      unit: suggestion.defaultUnit,
      category: suggestion.category,
      expiryDate: expiryDate.toISOString().split('T')[0],
      image: suggestion.image,
    });
    setUseAutocomplete(false);
    setShowQuickAdd(false);
  };

  const handleClose = () => {
    setFormData({
      name: '',
      quantity: '',
      unit: 'g',
      category: 'Sonstiges',
      expiryDate: '',
      image: '',
    });
    setShowQuickAdd(true);
    setUseAutocomplete(true);
    onClose();
  };

  // Auto-fill data when typing manually
  const handleNameChange = (value: string) => {
    setFormData(prev => ({ ...prev, name: value }));
    
    // Only auto-fill for new items
    if (value.length >= 3) {
      const suggestion = getFoodSuggestion(value);
      if (suggestion && !formData.quantity && !formData.category) {
        const expiryDate = new Date();
        expiryDate.setDate(expiryDate.getDate() + suggestion.defaultExpiryDays);
        
        setFormData(prev => ({
          ...prev,
          quantity: suggestion.defaultQuantity,
          unit: suggestion.defaultUnit,
          category: suggestion.category,
          expiryDate: expiryDate.toISOString().split('T')[0],
          image: suggestion.image,
        }));
      }
    }
  };

  // Get tomorrow's date as minimum date
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const minDate = tomorrow.toISOString().split('T')[0];

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md mx-4 rounded-3xl bg-white/95 backdrop-blur-sm max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center space-x-3 mb-2">
            <div className="w-12 h-12 bg-fridge-blue-100 rounded-2xl flex items-center justify-center">
              <Package className="w-6 h-6 text-fridge-blue-600" />
            </div>
            <div>
              <DialogTitle className="text-xl font-bold">
                ➕ Neues Produkt
              </DialogTitle>
              <p className="text-sm text-fridge-navy-600">
                Produkt zu Vorräten hinzufügen
              </p>
            </div>
          </div>
        </DialogHeader>
        
        {/* Smart Input Section */}
        {useAutocomplete && (
          <div className="mb-6">
            <div className="flex items-center space-x-2 mb-3">
              <Sparkles className="w-5 h-5 text-fridge-blue-600" />
              <h3 className="font-bold text-fridge-navy-900">🤖 Intelligente Eingabe:</h3>
            </div>
            <FoodAutocomplete
              value={formData.name}
              onChange={handleNameChange}
              onSuggestionSelect={handleSuggestionSelect}
              placeholder="Lebensmittel eingeben für Vorschläge..."
              className="h-12 rounded-2xl border-2 text-base focus:border-fridge-blue-400"
            />
            <div className="mt-3 text-center">
              <Button
                variant="ghost"
                onClick={() => setUseAutocomplete(false)}
                className="text-sm text-fridge-blue-600 hover:text-fridge-blue-800 font-semibold"
              >
                Oder Schnellauswahl verwenden →
              </Button>
            </div>
          </div>
        )}

        {/* Quick Add Section */}
        {showQuickAdd && !useAutocomplete && (
          <div className="mb-6">
            <h3 className="font-bold text-fridge-navy-900 mb-3">⚡ Schnell hinzufügen:</h3>
            <div className="grid grid-cols-2 gap-2">
              {quickAddPresets.map((preset, index) => (
                <Button
                  key={index}
                  variant="outline"
                  onClick={() => handleQuickAdd(preset)}
                  className="h-auto p-3 rounded-2xl border-2 text-left hover:bg-fridge-blue-50 hover:border-fridge-blue-300"
                >
                  <div>
                    <div className="font-semibold text-sm">{preset.name}</div>
                    <div className="text-xs text-gray-600">{preset.quantity} {preset.unit}</div>
                  </div>
                </Button>
              ))}
            </div>
            <div className="mt-4 text-center">
              <Button
                variant="ghost"
                onClick={() => setUseAutocomplete(true)}
                className="text-sm text-fridge-blue-600 hover:text-fridge-blue-800 font-semibold"
              >
                Oder intelligente Eingabe verwenden →
              </Button>
            </div>
          </div>
        )}

        {/* Manual Form */}
        {!showQuickAdd && !useAutocomplete && (
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-sm font-bold mb-2 text-fridge-navy-700">
                Produktname *
              </label>
              <Input
                value={formData.name}
                onChange={(e) => handleNameChange(e.target.value)}
                placeholder="z.B. Bananen"
                required
                className="h-12 rounded-2xl border-2 text-base focus:border-fridge-blue-400"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-bold mb-2 text-fridge-navy-700">
                  Menge *
                </label>
                <Input
                  value={formData.quantity}
                  onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                  placeholder="1.2"
                  required
                  className="h-12 rounded-2xl border-2 text-base focus:border-fridge-blue-400"
                />
              </div>
              
              <div>
                <label className="block text-sm font-bold mb-2 text-fridge-navy-700">
                  Einheit
                </label>
                <select
                  value={formData.unit}
                  onChange={(e) => setFormData({ ...formData, unit: e.target.value })}
                  className="w-full h-12 px-4 py-2 border-2 border-input rounded-2xl bg-background text-base font-medium focus:border-fridge-blue-400"
                >
                  {units.map((unit) => (
                    <option key={unit} value={unit}>
                      {unit}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-bold mb-2 text-fridge-navy-700">
                Kategorie
              </label>
              <select
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                className="w-full h-12 px-4 py-2 border-2 border-input rounded-2xl bg-background text-base font-medium focus:border-fridge-blue-400"
              >
                {categories.map((category) => (
                  <option key={category} value={category}>
                    {category}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-bold mb-2 text-fridge-navy-700 flex items-center">
                <Calendar className="w-4 h-4 mr-2" />
                Ablaufdatum * (Datum auswählen)
              </label>
              <Input
                type="date"
                value={formData.expiryDate}
                onChange={(e) => setFormData({ ...formData, expiryDate: e.target.value })}
                min={minDate}
                required
                className="h-12 rounded-2xl border-2 text-base focus:border-fridge-blue-400"
              />
              <p className="text-xs text-fridge-navy-500 mt-1">
                Mindestens morgen oder später
              </p>
            </div>

            {/* Show image preview if available */}
            {formData.image && (
              <div>
                <label className="block text-sm font-bold mb-2 text-fridge-navy-700">
                  Produktbild (automatisch erkannt)
                </label>
                <div className="w-20 h-20 rounded-2xl overflow-hidden bg-gray-100 shadow-md">
                  <img
                    src={formData.image}
                    alt={formData.name}
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            )}

            <DialogFooter className="pt-4">
              <div className="w-full space-y-3">
                <Button 
                  type="submit" 
                  className="w-full h-14 bg-fridge-green-600 hover:bg-fridge-green-700 rounded-2xl text-lg font-bold"
                >
                  ➕ Hinzufügen
                </Button>
                
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={handleClose}
                  className="w-full h-12 rounded-2xl text-lg font-semibold border-2 border-fridge-blue-200 hover:border-fridge-blue-300"
                >
                  Abbrechen
                </Button>
              </div>
            </DialogFooter>
          </form>
        )}

        {/* Back to options buttons when in manual mode */}
        {!showQuickAdd && !useAutocomplete && (
          <div className="text-center pt-2 space-y-2">
            <Button
              variant="ghost"
              onClick={() => setUseAutocomplete(true)}
              className="text-sm text-fridge-blue-600 hover:text-fridge-blue-800 font-semibold block w-full"
            >
              ← Zurück zur intelligenten Eingabe
            </Button>
            <Button
              variant="ghost"
              onClick={() => setShowQuickAdd(true)}
              className="text-sm text-fridge-blue-600 hover:text-fridge-blue-800 font-semibold block w-full"
            >
              ← Zurück zur Schnellauswahl
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};
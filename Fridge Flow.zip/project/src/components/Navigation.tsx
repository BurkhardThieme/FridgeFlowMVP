import React from 'react';
import { NavigationTab } from '../types';
import { Home, ChefHat, ShoppingCart, User } from 'lucide-react';

interface NavigationProps {
  activeTab: NavigationTab;
  onTabChange: (tab: NavigationTab) => void;
}

export const Navigation: React.FC<NavigationProps> = ({ activeTab, onTabChange }) => {
  const tabs = [
    { id: 'home' as NavigationTab, label: 'Vorräte', icon: Home },
    { id: 'recipes' as NavigationTab, label: 'Rezepte', icon: ChefHat },
    { id: 'shopping' as NavigationTab, label: 'Einkaufen', icon: ShoppingCart },
    { id: 'account' as NavigationTab, label: 'Account', icon: User },
  ];

  return (
    <div className="bg-white/95 backdrop-blur-sm border-t-2 border-fridge-blue-100 px-4 py-3 safe-area-bottom shadow-2xl">
      <div className="flex justify-around items-center max-w-md mx-auto">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`flex flex-col items-center justify-center py-3 px-4 rounded-3xl transition-all duration-300 min-w-[70px] ${
                isActive
                  ? 'text-fridge-green-600 bg-fridge-green-100 scale-110 shadow-lg'
                  : 'text-fridge-navy-500 hover:text-fridge-navy-700 active:scale-95 hover:bg-fridge-blue-100'
              }`}
            >
              <Icon className={`w-7 h-7 mb-1 ${isActive ? 'stroke-2' : 'stroke-1.5'}`} />
              <span className={`text-xs font-semibold ${isActive ? 'font-bold' : ''}`}>
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
import React, { useState } from 'react';
import { Button } from './ui/button';
import { Camera, Upload, AlertCircle, Zap } from 'lucide-react';
import { takePicture, pickFromGallery, triggerHaptic } from '../capacitor-plugins';
import { useCapacitor } from '../hooks/useCapacitor';
import { ImpactStyle } from '@capacitor/haptics';

interface CameraScanProps {
  onImageCaptured: (imagePath: string) => void;
  onError: (error: string) => void;
}

export const CameraScan: React.FC<CameraScanProps> = ({ onImageCaptured, onError }) => {
  const [isLoading, setIsLoading] = useState(false);
  const { isNative } = useCapacitor();

  const handleTakePicture = async () => {
    setIsLoading(true);
    
    try {
      await triggerHaptic(ImpactStyle.Light);
      const imagePath = await takePicture();
      
      if (imagePath) {
        onImageCaptured(imagePath);
        await triggerHaptic(ImpactStyle.Medium);
      }
    } catch (error) {
      console.error('Camera error:', error);
      onError('Kamera konnte nicht geöffnet werden');
      await triggerHaptic(ImpactStyle.Heavy);
    } finally {
      setIsLoading(false);
    }
  };

  const handlePickFromGallery = async () => {
    setIsLoading(true);
    
    try {
      await triggerHaptic(ImpactStyle.Light);
      const imagePath = await pickFromGallery();
      
      if (imagePath) {
        onImageCaptured(imagePath);
        await triggerHaptic(ImpactStyle.Medium);
      }
    } catch (error) {
      console.error('Gallery error:', error);
      onError('Galerie konnte nicht geöffnet werden');
      await triggerHaptic(ImpactStyle.Heavy);
    } finally {
      setIsLoading(false);
    }
  };

  if (!isNative) {
    // Enhanced fallback for web with file input
    return (
      <div className="space-y-4">
        <div className="text-center py-6 bg-gradient-to-br from-orange-50 to-yellow-50 rounded-2xl border-2 border-orange-200">
          <div className="w-16 h-16 bg-orange-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Camera className="w-8 h-8 text-orange-600" />
          </div>
          <h3 className="text-lg font-semibold text-orange-900 mb-2">
            📱 Kamera in der App verfügbar
          </h3>
          <p className="text-orange-700 mb-4 px-4">
            Installieren Sie die App auf Ihrem Handy für die beste Kamera-Erfahrung
          </p>
          
          <div className="bg-orange-100 rounded-xl p-3 mx-4">
            <div className="flex items-center justify-center space-x-2 mb-2">
              <Zap className="w-4 h-4 text-orange-600" />
              <span className="font-bold text-orange-800 text-sm">Web-Version</span>
            </div>
            <p className="text-xs text-orange-700">
              Sie können trotzdem Bilder hochladen und die OCR-Funktion nutzen!
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <Button
        onClick={handleTakePicture}
        disabled={isLoading}
        className="w-full h-16 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 rounded-2xl text-lg font-semibold shadow-lg"
      >
        <Camera className="w-6 h-6 mr-3" />
        {isLoading ? 'Öffne Kamera...' : '📸 Kassenbon fotografieren'}
      </Button>

      <Button
        onClick={handlePickFromGallery}
        disabled={isLoading}
        variant="outline"
        className="w-full h-16 rounded-2xl text-lg font-semibold border-2 shadow-lg"
      >
        <Upload className="w-6 h-6 mr-3" />
        {isLoading ? 'Öffne Galerie...' : '🖼️ Aus Galerie wählen'}
      </Button>
    </div>
  );
};
import React from 'react';
import { Recipe } from '../types';
import { Clock, ChefHat, Sparkles } from 'lucide-react';

interface RecipeCardProps {
  recipe: Recipe;
  availableIngredients: string[];
  onClick: (recipe: Recipe) => void;
}

export const RecipeCard: React.FC<RecipeCardProps> = ({
  recipe,
  availableIngredients,
  onClick,
}) => {
  // Improved ingredient matching function
  const ingredientMatches = (recipeIngredient: string, availableIngredient: string): boolean => {
    const recipeItem = recipeIngredient.toLowerCase();
    const available = availableIngredient.toLowerCase();
    
    // Direct match
    if (recipeItem === available) return true;
    
    // Partial matches
    if (recipeItem.includes(available) || available.includes(recipeItem)) return true;
    
    // Common ingredient variations
    const variations: { [key: string]: string[] } = {
      'äpfel': ['apfel', 'äpfel'],
      'apfel': ['apfel', 'äpfel'],
      'tomaten': ['tomate', 'tomaten'],
      'tomate': ['tomate', 'tomaten'],
      'zwiebeln': ['zwiebel', 'zwiebeln'],
      'zwiebel': ['zwiebel', 'zwiebeln'],
      'karotten': ['karotte', 'karotten', 'möhre', 'möhren'],
      'karotte': ['karotte', 'karotten', 'möhre', 'möhren'],
      'möhre': ['karotte', 'karotten', 'möhre', 'möhren'],
      'möhren': ['karotte', 'karotten', 'möhre', 'möhren'],
      'paprika': ['paprika', 'paprikaschote'],
      'hähnchenbrust': ['hähnchen', 'hähnchenbrust', 'hühnchen', 'hühnchenbrust'],
      'hähnchen': ['hähnchen', 'hähnchenbrust', 'hühnchen', 'hühnchenbrust'],
      'hühnchen': ['hähnchen', 'hähnchenbrust', 'hühnchen', 'hühnchenbrust'],
      'nudeln': ['nudel', 'nudeln', 'pasta'],
      'nudel': ['nudel', 'nudeln', 'pasta'],
      'pasta': ['nudel', 'nudeln', 'pasta'],
    };
    
    // Check variations
    const recipeVariations = variations[recipeItem] || [recipeItem];
    const availableVariations = variations[available] || [available];
    
    return recipeVariations.some(rv => 
      availableVariations.some(av => rv === av || rv.includes(av) || av.includes(rv))
    );
  };

  const matchingIngredients = recipe.ingredients.filter(ingredient =>
    availableIngredients.some(available => 
      ingredientMatches(ingredient, available)
    )
  );

  const matchPercentage = Math.round((matchingIngredients.length / recipe.ingredients.length) * 100);

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return 'text-green-700 bg-green-100 border-green-200';
      case 'medium': return 'text-yellow-700 bg-yellow-100 border-yellow-200';
      case 'hard': return 'text-red-700 bg-red-100 border-red-200';
      default: return 'text-gray-700 bg-gray-100 border-gray-200';
    }
  };

  const getDifficultyText = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return 'Einfach';
      case 'medium': return 'Mittel';
      case 'hard': return 'Schwer';
      default: return difficulty;
    }
  };

  const getMatchColor = () => {
    if (matchPercentage >= 80) return 'bg-gradient-to-r from-green-500 to-emerald-500 text-white';
    if (matchPercentage >= 50) return 'bg-gradient-to-r from-yellow-500 to-orange-500 text-white';
    return 'bg-gradient-to-r from-gray-400 to-gray-500 text-white';
  };

  return (
    <button
      onClick={() => onClick(recipe)}
      className="w-full bg-white/90 backdrop-blur-sm rounded-2xl overflow-hidden shadow-lg hover:shadow-xl border-2 border-gray-200 hover:border-orange-300 active:scale-98 transition-all duration-300 text-left group"
    >
      {/* Kompakteres Recipe Image mit Overlay */}
      {recipe.image && (
        <div className="h-32 overflow-hidden relative">
          <img
            src={recipe.image}
            alt={recipe.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
          {/* Gradient overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
          
          {/* Match percentage badge */}
          <div className={`absolute top-2 right-2 px-2 py-1 rounded-xl text-xs font-bold shadow-lg ${getMatchColor()}`}>
            <div className="flex items-center space-x-1">
              <Sparkles className="w-3 h-3" />
              <span>{matchPercentage}%</span>
            </div>
          </div>
        </div>
      )}
      
      <div className="p-4">
        {/* Kompakter Header */}
        <div className="flex justify-between items-start mb-2">
          <h3 className="font-bold text-lg text-gray-900 flex-1 pr-2 leading-tight">
            {recipe.name}
          </h3>
        </div>
        
        {/* Kompakte Recipe Meta */}
        <div className="flex items-center space-x-3 text-sm text-gray-600 mb-3">
          <div className="flex items-center bg-gray-100 rounded-xl px-2 py-1">
            <Clock className="w-3 h-3 mr-1" />
            <span className="font-semibold text-xs">{recipe.cookingTime} Min</span>
          </div>
          
          <div className={`px-2 py-1 rounded-xl text-xs font-bold border ${getDifficultyColor(recipe.difficulty)}`}>
            {getDifficultyText(recipe.difficulty)}
          </div>
        </div>
        
        {/* Kompakte Ingredients Info */}
        <div className="text-sm">
          <div className="flex items-center justify-between mb-2">
            <p className="text-gray-700 font-semibold text-xs">
              Verfügbar: {matchingIngredients.length}/{recipe.ingredients.length}
            </p>
            <ChefHat className="w-4 h-4 text-orange-500" />
          </div>
          
          <div className="flex flex-wrap gap-1">
            {recipe.ingredients.slice(0, 3).map((ingredient, index) => (
              <span
                key={index}
                className={`px-2 py-0.5 rounded-xl text-xs font-bold border ${
                  matchingIngredients.includes(ingredient)
                    ? 'bg-green-100 text-green-800 border-green-200'
                    : 'bg-gray-100 text-gray-600 border-gray-200'
                }`}
              >
                {ingredient}
              </span>
            ))}
            {recipe.ingredients.length > 3 && (
              <span className="px-2 py-0.5 rounded-xl text-xs font-bold bg-gray-100 text-gray-600 border border-gray-200">
                +{recipe.ingredients.length - 3}
              </span>
            )}
          </div>
        </div>
      </div>
    </button>
  );
};
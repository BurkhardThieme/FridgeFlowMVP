import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from './ui/dialog';
import { Button } from './ui/button';
import { FoodItem } from '../types';
import { AlertTriangle, ChefHat, Calendar, Sparkles } from 'lucide-react';

interface ExpiringItemsDialogProps {
  isOpen: boolean;
  onClose: () => void;
  items: FoodItem[];
  onGoToRecipes: (ingredients: string[]) => void;
}

export const ExpiringItemsDialog: React.FC<ExpiringItemsDialogProps> = ({
  isOpen,
  onClose,
  items,
  onGoToRecipes,
}) => {
  const getDaysUntilExpiry = (expiryDate: Date) => {
    const today = new Date();
    const expiry = new Date(expiryDate);
    const diffTime = expiry.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const getExpiryColor = (daysLeft: number) => {
    if (daysLeft < 0) return 'text-red-700 bg-red-100 border-red-200';
    if (daysLeft <= 1) return 'text-red-700 bg-red-100 border-red-200';
    if (daysLeft <= 3) return 'text-orange-700 bg-orange-100 border-orange-200';
    return 'text-yellow-700 bg-yellow-100 border-yellow-200';
  };

  const getExpiryText = (daysLeft: number) => {
    if (daysLeft < 0) return 'Abgelaufen';
    if (daysLeft === 0) return 'Heute';
    if (daysLeft === 1) return 'Morgen';
    return `${daysLeft} Tage`;
  };

  const handleGoToRecipes = () => {
    const ingredients = items.map(item => item.name);
    onGoToRecipes(ingredients);
    onClose();
  };

  const sortedItems = [...items].sort((a, b) => {
    const aDays = getDaysUntilExpiry(a.expiryDate);
    const bDays = getDaysUntilExpiry(b.expiryDate);
    return aDays - bDays;
  });

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md mx-4 rounded-3xl max-h-[85vh] overflow-hidden flex flex-col bg-white/95 backdrop-blur-sm border-2 border-orange-200">
        <DialogHeader className="pb-4">
          <div className="flex items-center space-x-4 mb-3">
            <div className="w-16 h-16 bg-gradient-to-br from-orange-500 to-red-500 rounded-3xl flex items-center justify-center shadow-lg">
              <AlertTriangle className="w-8 h-8 text-white" />
            </div>
            <div>
              <DialogTitle className="text-2xl font-bold text-gray-900">
                ⚠️ Läuft bald ab
              </DialogTitle>
              <p className="text-sm text-gray-600 font-medium">
                {items.length} Produkt{items.length !== 1 ? 'e' : ''} sollten bald verwendet werden
              </p>
            </div>
          </div>
        </DialogHeader>
        
        <div className="flex-1 overflow-y-auto space-y-3 py-2">
          {sortedItems.map((item) => {
            const daysLeft = getDaysUntilExpiry(item.expiryDate);
            
            return (
              <div key={item.id} className="flex items-center space-x-4 p-4 bg-white/80 backdrop-blur-sm rounded-3xl border-2 border-gray-200 shadow-sm">
                {/* Product Image */}
                <div className="w-16 h-16 rounded-2xl overflow-hidden bg-gray-200 flex-shrink-0 shadow-md">
                  {item.image ? (
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full bg-gradient-to-br from-gray-300 to-gray-400 flex items-center justify-center">
                      <span className="text-gray-500 text-sm">📦</span>
                    </div>
                  )}
                </div>
                
                {/* Product Info */}
                <div className="flex-1 min-w-0">
                  <h3 className="font-bold text-gray-900 truncate text-lg">
                    {item.name}
                  </h3>
                  <p className="text-sm text-gray-600 font-medium">
                    {item.quantity} {item.unit} • {item.category}
                  </p>
                </div>

                {/* Expiry Badge */}
                <div className={`px-4 py-2 rounded-2xl text-sm font-bold border-2 ${getExpiryColor(daysLeft)}`}>
                  {getExpiryText(daysLeft)}
                </div>
              </div>
            );
          })}
        </div>

        <DialogFooter className="pt-6 space-y-4">
          <div className="w-full space-y-4">
            <Button 
              onClick={handleGoToRecipes}
              className="w-full h-16 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 rounded-3xl text-lg font-bold shadow-lg hover:shadow-xl active:scale-98 transition-all duration-300"
            >
              <div className="flex items-center justify-center space-x-3">
                <Sparkles className="w-6 h-6" />
                <ChefHat className="w-6 h-6" />
                <span>Passende Rezepte finden</span>
              </div>
            </Button>
            
            <Button 
              variant="outline" 
              onClick={onClose}
              className="w-full h-14 rounded-3xl text-lg font-bold border-2 border-gray-300 bg-white/80 backdrop-blur-sm hover:bg-white active:scale-98 transition-all duration-300"
            >
              Schließen
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
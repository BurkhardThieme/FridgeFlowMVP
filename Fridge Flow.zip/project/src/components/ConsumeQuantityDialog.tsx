import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { FoodItem } from '../types';
import { Minus, Plus, TrendingDown } from 'lucide-react';

interface ConsumeQuantityDialogProps {
  isOpen: boolean;
  onClose: () => void;
  item: FoodItem | null;
  onConsume: (id: string, consumedQuantity: number, newQuantity: string) => void;
}

export const ConsumeQuantityDialog: React.FC<ConsumeQuantityDialogProps> = ({
  isOpen,
  onClose,
  item,
  onConsume,
}) => {
  const [consumeAmount, setConsumeAmount] = useState('');

  if (!item) return null;

  const currentQuantity = parseFloat(item.quantity) || 0;
  const consumeQuantity = parseFloat(consumeAmount) || 0;
  const remainingQuantity = Math.max(0, currentQuantity - consumeQuantity);

  const handleConsume = () => {
    if (consumeQuantity > 0 && consumeQuantity <= currentQuantity) {
      const newQuantity = remainingQuantity.toString();
      onConsume(item.id, consumeQuantity, newQuantity);
      handleClose();
    }
  };

  const handleClose = () => {
    setConsumeAmount('');
    onClose();
  };

  const handleQuickConsume = (percentage: number) => {
    const amount = (currentQuantity * percentage / 100).toFixed(1);
    setConsumeAmount(amount);
  };

  const isValidAmount = consumeQuantity > 0 && consumeQuantity <= currentQuantity;

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md mx-4 rounded-3xl">
        <DialogHeader>
          <div className="flex items-center space-x-3 mb-2">
            <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
              <TrendingDown className="w-6 h-6 text-orange-600" />
            </div>
            <div>
              <DialogTitle className="text-xl font-bold text-gray-900">
                Menge verbrauchen
              </DialogTitle>
              <p className="text-sm text-gray-600">
                {item.name} • {item.quantity} {item.unit} verfügbar
              </p>
            </div>
          </div>
        </DialogHeader>
        
        <div className="space-y-6 py-4">
          {/* Product Image */}
          <div className="flex justify-center">
            <div className="w-20 h-20 rounded-2xl overflow-hidden bg-gray-100">
              {item.image ? (
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full bg-gray-200 flex items-center justify-center">
                  <span className="text-gray-400 text-lg">📦</span>
                </div>
              )}
            </div>
          </div>

          {/* Quick Actions */}
          <div>
            <p className="text-sm font-medium text-gray-700 mb-3">Schnellauswahl:</p>
            <div className="grid grid-cols-4 gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleQuickConsume(25)}
                className="rounded-xl text-xs"
              >
                25%
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleQuickConsume(50)}
                className="rounded-xl text-xs"
              >
                50%
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleQuickConsume(75)}
                className="rounded-xl text-xs"
              >
                75%
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setConsumeAmount(item.quantity)}
                className="rounded-xl text-xs"
              >
                Alles
              </Button>
            </div>
          </div>

          {/* Manual Input */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Verbrauchte Menge ({item.unit})
            </label>
            <div className="flex items-center space-x-3">
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  const newAmount = Math.max(0, consumeQuantity - 0.1);
                  setConsumeAmount(newAmount.toFixed(1));
                }}
                className="w-10 h-10 rounded-full p-0"
                disabled={consumeQuantity <= 0}
              >
                <Minus className="w-4 h-4" />
              </Button>
              
              <Input
                type="number"
                value={consumeAmount}
                onChange={(e) => setConsumeAmount(e.target.value)}
                placeholder="0"
                min="0"
                max={item.quantity}
                step="0.1"
                className="text-center text-lg font-semibold h-12 rounded-xl"
              />
              
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  const newAmount = Math.min(currentQuantity, consumeQuantity + 0.1);
                  setConsumeAmount(newAmount.toFixed(1));
                }}
                className="w-10 h-10 rounded-full p-0"
                disabled={consumeQuantity >= currentQuantity}
              >
                <Plus className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Preview */}
          {consumeAmount && (
            <div className="bg-gray-50 rounded-2xl p-4">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm text-gray-600">Aktuell:</span>
                <span className="font-semibold">{item.quantity} {item.unit}</span>
              </div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm text-gray-600">Verbraucht:</span>
                <span className="font-semibold text-orange-600">-{consumeQuantity} {item.unit}</span>
              </div>
              <div className="border-t border-gray-200 pt-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium text-gray-900">Verbleibt:</span>
                  <span className={`font-bold text-lg ${remainingQuantity === 0 ? 'text-red-600' : 'text-green-600'}`}>
                    {remainingQuantity} {item.unit}
                  </span>
                </div>
              </div>
              
              {remainingQuantity === 0 && (
                <div className="mt-3 p-3 bg-orange-50 border border-orange-200 rounded-xl">
                  <p className="text-sm text-orange-800 font-medium">
                    ⚠️ Das Produkt wird komplett verbraucht und aus den Vorräten entfernt.
                  </p>
                </div>
              )}
            </div>
          )}
        </div>

        <DialogFooter className="space-y-3">
          <div className="w-full space-y-3">
            <Button
              onClick={handleConsume}
              disabled={!isValidAmount}
              className={`w-full h-14 rounded-2xl text-lg font-semibold ${
                remainingQuantity === 0 
                  ? 'bg-red-600 hover:bg-red-700' 
                  : 'bg-orange-600 hover:bg-orange-700'
              }`}
            >
              {remainingQuantity === 0 ? 'Komplett verbrauchen' : 'Menge verbrauchen'}
            </Button>
            
            <Button
              variant="outline"
              onClick={handleClose}
              className="w-full h-12 rounded-2xl text-lg font-semibold border-2"
            >
              Abbrechen
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
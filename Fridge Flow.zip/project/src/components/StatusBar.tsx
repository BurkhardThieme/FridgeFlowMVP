import React from 'react';

export const StatusBar: React.FC = () => {
  const currentTime = new Date().toLocaleTimeString('de-DE', { 
    hour: '2-digit', 
    minute: '2-digit',
    hour12: false 
  });

  return (
    <div className="status-bar h-11 flex items-center justify-between px-6 pt-2 safe-area-top">
      <div className="text-sm font-semibold">{currentTime}</div>
      <div className="flex items-center space-x-1">
        {/* Signal bars */}
        <div className="flex items-end space-x-0.5">
          <div className="w-1 h-1 bg-white rounded-full"></div>
          <div className="w-1 h-2 bg-white rounded-full"></div>
          <div className="w-1 h-3 bg-white rounded-full"></div>
          <div className="w-1 h-4 bg-white rounded-full"></div>
        </div>
        {/* WiFi icon */}
        <div className="w-4 h-3 relative ml-1">
          <div className="absolute bottom-0 left-0 w-1 h-1 bg-white rounded-full"></div>
          <div className="absolute bottom-0 left-1 w-1 h-2 bg-white rounded-full"></div>
          <div className="absolute bottom-0 left-2 w-1 h-3 bg-white rounded-full"></div>
        </div>
        {/* Battery */}
        <div className="w-6 h-3 border border-white rounded-sm ml-2 relative">
          <div className="w-4 h-1 bg-white rounded-sm m-0.5"></div>
          <div className="absolute -right-0.5 top-1 w-0.5 h-1 bg-white rounded-r-sm"></div>
        </div>
      </div>
    </div>
  );
};
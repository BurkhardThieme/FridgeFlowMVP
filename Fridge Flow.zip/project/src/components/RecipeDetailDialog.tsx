import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from './ui/dialog';
import { Button } from './ui/button';
import { Recipe } from '../types';
import { Clock, ChefHat, ShoppingCart, Check, Plus } from 'lucide-react';

interface RecipeDetailDialogProps {
  isOpen: boolean;
  onClose: () => void;
  recipe: Recipe | null;
  availableIngredients: string[];
  onAddMissingToShopping: (ingredients: string[]) => void;
}

export const RecipeDetailDialog: React.FC<RecipeDetailDialogProps> = ({
  isOpen,
  onClose,
  recipe,
  availableIngredients,
  onAddMissingToShopping,
}) => {
  if (!recipe) return null;

  // Improved ingredient matching function
  const ingredientMatches = (recipeIngredient: string, availableIngredient: string): boolean => {
    const recipeItem = recipeIngredient.toLowerCase();
    const available = availableIngredient.toLowerCase();
    
    // Direct match
    if (recipeItem === available) return true;
    
    // Partial matches
    if (recipeItem.includes(available) || available.includes(recipeItem)) return true;
    
    // Common ingredient variations
    const variations: { [key: string]: string[] } = {
      'äpfel': ['apfel', 'äpfel'],
      'apfel': ['apfel', 'äpfel'],
      'tomaten': ['tomate', 'tomaten'],
      'tomate': ['tomate', 'tomaten'],
      'zwiebeln': ['zwiebel', 'zwiebeln'],
      'zwiebel': ['zwiebel', 'zwiebeln'],
      'karotten': ['karotte', 'karotten', 'möhre', 'möhren'],
      'karotte': ['karotte', 'karotten', 'möhre', 'möhren'],
      'möhre': ['karotte', 'karotten', 'möhre', 'möhren'],
      'möhren': ['karotte', 'karotten', 'möhre', 'möhren'],
      'paprika': ['paprika', 'paprikaschote'],
      'hähnchenbrust': ['hähnchen', 'hähnchenbrust', 'hühnchen', 'hühnchenbrust'],
      'hähnchen': ['hähnchen', 'hähnchenbrust', 'hühnchen', 'hühnchenbrust'],
      'hühnchen': ['hähnchen', 'hähnchenbrust', 'hühnchen', 'hühnchenbrust'],
      'nudeln': ['nudel', 'nudeln', 'pasta'],
      'nudel': ['nudel', 'nudeln', 'pasta'],
      'pasta': ['nudel', 'nudeln', 'pasta'],
    };
    
    // Check variations
    const recipeVariations = variations[recipeItem] || [recipeItem];
    const availableVariations = variations[available] || [available];
    
    return recipeVariations.some(rv => 
      availableVariations.some(av => rv === av || rv.includes(av) || av.includes(rv))
    );
  };

  const availableIngredientsList = recipe.ingredients.filter(ingredient =>
    availableIngredients.some(available => 
      ingredientMatches(ingredient, available)
    )
  );

  const missingIngredients = recipe.ingredients.filter(ingredient =>
    !availableIngredients.some(available => 
      ingredientMatches(ingredient, available)
    )
  );

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return 'text-green-600 bg-green-50';
      case 'medium': return 'text-yellow-600 bg-yellow-50';
      case 'hard': return 'text-red-600 bg-red-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  const getDifficultyText = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return 'Einfach';
      case 'medium': return 'Mittel';
      case 'hard': return 'Schwer';
      default: return difficulty;
    }
  };

  const handleAddMissingToShopping = () => {
    onAddMissingToShopping(missingIngredients);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-lg mx-4 rounded-3xl max-h-[90vh] overflow-hidden flex flex-col">
        {/* Recipe Image */}
        {recipe.image && (
          <div className="h-48 overflow-hidden rounded-t-3xl -m-6 mb-0">
            <img
              src={recipe.image}
              alt={recipe.name}
              className="w-full h-full object-cover"
            />
          </div>
        )}

        <DialogHeader className="pt-6">
          <DialogTitle className="text-2xl font-bold text-gray-900 mb-2">
            {recipe.name}
          </DialogTitle>
          
          {/* Recipe Meta */}
          <div className="flex items-center space-x-4 text-sm text-gray-600">
            <div className="flex items-center">
              <Clock className="w-4 h-4 mr-1" />
              {recipe.cookingTime} Min
            </div>
            
            <div className={`px-3 py-1 rounded-full text-xs font-medium ${getDifficultyColor(recipe.difficulty)}`}>
              {getDifficultyText(recipe.difficulty)}
            </div>
          </div>
        </DialogHeader>
        
        <div className="flex-1 overflow-y-auto space-y-6 py-4">
          {/* Ingredients Status */}
          <div>
            <h3 className="font-semibold text-gray-900 mb-3">
              Zutaten ({availableIngredientsList.length}/{recipe.ingredients.length} verfügbar)
            </h3>
            
            <div className="space-y-2">
              {recipe.ingredients.map((ingredient, index) => {
                const isAvailable = availableIngredients.some(available => 
                  ingredientMatches(ingredient, available)
                );
                
                return (
                  <div key={index} className="flex items-center space-x-3 p-3 rounded-xl bg-gray-50">
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                      isAvailable ? 'bg-green-100' : 'bg-gray-200'
                    }`}>
                      {isAvailable ? (
                        <Check className="w-4 h-4 text-green-600" />
                      ) : (
                        <div className="w-2 h-2 bg-gray-400 rounded-full" />
                      )}
                    </div>
                    <span className={`flex-1 font-medium ${isAvailable ? 'text-gray-900' : 'text-gray-500'}`}>
                      {ingredient}
                    </span>
                    {!isAvailable && (
                      <span className="text-xs text-orange-600 bg-orange-100 px-2 py-1 rounded-full font-bold">
                        Fehlt
                      </span>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Instructions */}
          <div>
            <h3 className="font-semibold text-gray-900 mb-3">Zubereitung</h3>
            <div className="space-y-3">
              {recipe.instructions.map((instruction, index) => (
                <div key={index} className="flex space-x-3">
                  <div className="w-6 h-6 bg-green-100 text-green-600 rounded-full flex items-center justify-center text-sm font-semibold flex-shrink-0 mt-0.5">
                    {index + 1}
                  </div>
                  <p className="text-gray-700 leading-relaxed font-medium">{instruction}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        <DialogFooter className="pt-4 space-y-3">
          <div className="w-full space-y-3">
            {missingIngredients.length > 0 && (
              <Button 
                onClick={handleAddMissingToShopping}
                className="w-full h-14 bg-green-600 hover:bg-green-700 rounded-2xl text-lg font-semibold"
              >
                <ShoppingCart className="w-6 h-6 mr-3" />
                {missingIngredients.length} fehlende Zutat{missingIngredients.length !== 1 ? 'en' : ''} zur Einkaufsliste
              </Button>
            )}
            
            <Button 
              variant="outline" 
              onClick={onClose}
              className="w-full h-12 rounded-2xl text-lg font-semibold border-2"
            >
              Schließen
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
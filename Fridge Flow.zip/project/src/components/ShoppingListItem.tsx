import React from 'react';
import { ShoppingItem } from '../types';
import { Button } from './ui/button';
import { Check, X, Package } from 'lucide-react';

interface ShoppingListItemProps {
  item: ShoppingItem;
  onToggle: (id: string) => void;
  onRemove: (id: string) => void;
}

// Korrigierte und erweiterte Bild-Datenbank für Einkaufsliste
const getItemImage = (itemName: string): string => {
  const name = itemName.toLowerCase();
  
  const imageMap: { [key: string]: string } = {
    // Milchprodukte
    'milch': 'https://images.pexels.com/photos/248412/pexels-photo-248412.jpeg?auto=compress&cs=tinysrgb&w=200',
    'joghurt': 'https://images.pexels.com/photos/1435735/pexels-photo-1435735.jpeg?auto=compress&cs=tinysrgb&w=200',
    'käse': 'https://images.pexels.com/photos/773253/pexels-photo-773253.jpeg?auto=compress&cs=tinysrgb&w=200',
    'feta': 'https://images.pexels.com/photos/1213710/pexels-photo-1213710.jpeg?auto=compress&cs=tinysrgb&w=200',
    'mozzarella': 'https://images.pexels.com/photos/4033328/pexels-photo-4033328.jpeg?auto=compress&cs=tinysrgb&w=200',
    'butter': 'https://images.pexels.com/photos/479643/pexels-photo-479643.jpeg?auto=compress&cs=tinysrgb&w=200',
    'eier': 'https://images.pexels.com/photos/162712/egg-white-food-protein-162712.jpeg?auto=compress&cs=tinysrgb&w=200',
    
    // Getreide
    'brot': 'https://images.pexels.com/photos/209206/pexels-photo-209206.jpeg?auto=compress&cs=tinysrgb&w=200',
    'nudeln': 'https://images.pexels.com/photos/1437267/pexels-photo-1437267.jpeg?auto=compress&cs=tinysrgb&w=200',
    'pasta': 'https://images.pexels.com/photos/1437267/pexels-photo-1437267.jpeg?auto=compress&cs=tinysrgb&w=200',
    'reis': 'https://images.pexels.com/photos/723198/pexels-photo-723198.jpeg?auto=compress&cs=tinysrgb&w=200',
    
    // Obst
    'äpfel': 'https://images.pexels.com/photos/102104/pexels-photo-102104.jpeg?auto=compress&cs=tinysrgb&w=200',
    'apfel': 'https://images.pexels.com/photos/102104/pexels-photo-102104.jpeg?auto=compress&cs=tinysrgb&w=200',
    'bananen': 'https://images.pexels.com/photos/2872755/pexels-photo-2872755.jpeg?auto=compress&cs=tinysrgb&w=200',
    'banane': 'https://images.pexels.com/photos/2872755/pexels-photo-2872755.jpeg?auto=compress&cs=tinysrgb&w=200',
    'zitronen': 'https://images.pexels.com/photos/1414130/pexels-photo-1414130.jpeg?auto=compress&cs=tinysrgb&w=200',
    'zitrone': 'https://images.pexels.com/photos/1414130/pexels-photo-1414130.jpeg?auto=compress&cs=tinysrgb&w=200',
    'orangen': 'https://images.pexels.com/photos/161559/background-bitter-breakfast-bright-161559.jpeg?auto=compress&cs=tinysrgb&w=200',
    'orange': 'https://images.pexels.com/photos/161559/background-bitter-breakfast-bright-161559.jpeg?auto=compress&cs=tinysrgb&w=200',
    
    // Gemüse
    'tomaten': 'https://images.pexels.com/photos/533280/pexels-photo-533280.jpeg?auto=compress&cs=tinysrgb&w=200',
    'tomate': 'https://images.pexels.com/photos/533280/pexels-photo-533280.jpeg?auto=compress&cs=tinysrgb&w=200',
    'kirschtomaten': 'https://images.pexels.com/photos/533280/pexels-photo-533280.jpeg?auto=compress&cs=tinysrgb&w=200',
    'kirschtomate': 'https://images.pexels.com/photos/533280/pexels-photo-533280.jpeg?auto=compress&cs=tinysrgb&w=200',
    'karotten': 'https://images.pexels.com/photos/143133/pexels-photo-143133.jpeg?auto=compress&cs=tinysrgb&w=200',
    'karotte': 'https://images.pexels.com/photos/143133/pexels-photo-143133.jpeg?auto=compress&cs=tinysrgb&w=200',
    'möhren': 'https://images.pexels.com/photos/143133/pexels-photo-143133.jpeg?auto=compress&cs=tinysrgb&w=200',
    'möhre': 'https://images.pexels.com/photos/143133/pexels-photo-143133.jpeg?auto=compress&cs=tinysrgb&w=200',
    'paprika': 'https://images.pexels.com/photos/594137/pexels-photo-594137.jpeg?auto=compress&cs=tinysrgb&w=200',
    'zwiebeln': 'https://images.pexels.com/photos/533342/pexels-photo-533342.jpeg?auto=compress&cs=tinysrgb&w=200',
    'zwiebel': 'https://images.pexels.com/photos/533342/pexels-photo-533342.jpeg?auto=compress&cs=tinysrgb&w=200',
    'gurke': 'https://images.pexels.com/photos/37528/cucumber-salad-food-healthy-37528.jpeg?auto=compress&cs=tinysrgb&w=200',
    'gurken': 'https://images.pexels.com/photos/37528/cucumber-salad-food-healthy-37528.jpeg?auto=compress&cs=tinysrgb&w=200',
    'salat': 'https://images.pexels.com/photos/1352199/pexels-photo-1352199.jpeg?auto=compress&cs=tinysrgb&w=200',
    
    // Fleisch
    'hähnchen': 'https://images.pexels.com/photos/616354/pexels-photo-616354.jpeg?auto=compress&cs=tinysrgb&w=200',
    'hähnchenbrust': 'https://images.pexels.com/photos/616354/pexels-photo-616354.jpeg?auto=compress&cs=tinysrgb&w=200',
    'hackfleisch': 'https://images.pexels.com/photos/2338407/pexels-photo-2338407.jpeg?auto=compress&cs=tinysrgb&w=200',
    
    // Sonstiges
    'olivenöl': 'https://images.pexels.com/photos/33783/olive-oil-salad-dressing-cooking-olive.jpg?auto=compress&cs=tinysrgb&w=200',
    'öl': 'https://images.pexels.com/photos/33783/olive-oil-salad-dressing-cooking-olive.jpg?auto=compress&cs=tinysrgb&w=200',
    'salz': 'https://images.pexels.com/photos/1340116/pexels-photo-1340116.jpeg?auto=compress&cs=tinysrgb&w=200',
    'zucker': 'https://images.pexels.com/photos/1340116/pexels-photo-1340116.jpeg?auto=compress&cs=tinysrgb&w=200',
  };

  // Check for exact matches first
  if (imageMap[name]) {
    return imageMap[name];
  }

  // Check for partial matches
  for (const [key, image] of Object.entries(imageMap)) {
    if (name.includes(key) || key.includes(name)) {
      return image;
    }
  }

  // Default fallback
  return '';
};

export const ShoppingListItem: React.FC<ShoppingListItemProps> = ({
  item,
  onToggle,
  onRemove,
}) => {
  const itemImage = getItemImage(item.name);

  return (
    <div className={`flex items-center space-x-4 p-5 rounded-3xl border-2 transition-all duration-300 shadow-sm ${
      item.isCompleted 
        ? 'bg-gray-50/80 border-gray-200 backdrop-blur-sm' 
        : 'bg-white/90 border-gray-200 hover:border-blue-300 active:scale-98 backdrop-blur-sm shadow-lg hover:shadow-xl'
    }`}>
      {/* Product Image */}
      <div className={`w-16 h-16 rounded-2xl overflow-hidden shadow-md flex-shrink-0 ${
        item.isCompleted ? 'opacity-50' : ''
      }`}>
        {itemImage ? (
          <img
            src={itemImage}
            alt={item.name}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className={`w-full h-full flex items-center justify-center ${
            item.isCompleted ? 'bg-gray-200' : 'bg-blue-100'
          }`}>
            <Package className={`w-8 h-8 ${item.isCompleted ? 'text-gray-500' : 'text-blue-600'}`} />
          </div>
        )}
      </div>

      {/* Checkbox */}
      <Button
        size="sm"
        variant={item.isCompleted ? "default" : "outline"}
        onClick={() => onToggle(item.id)}
        className={`w-12 h-12 rounded-2xl p-0 shadow-md transition-all duration-300 ${
          item.isCompleted 
            ? 'bg-green-500 hover:bg-green-600 border-green-500' 
            : 'border-2 border-gray-300 hover:border-green-400 bg-white'
        }`}
      >
        <Check className={`w-6 h-6 ${item.isCompleted ? 'text-white' : 'text-gray-400'}`} />
      </Button>
      
      <div className={`flex-1 ${item.isCompleted ? 'line-through text-gray-500' : ''}`}>
        <p className="font-bold text-lg">{item.name}</p>
        <p className="text-sm text-gray-600 font-medium">
          {item.quantity} {item.unit} • {item.category}
        </p>
      </div>
      
      <Button
        size="sm"
        variant="ghost"
        onClick={() => onRemove(item.id)}
        className="w-12 h-12 rounded-2xl p-0 text-red-600 hover:text-red-700 hover:bg-red-100 shadow-md"
      >
        <X className="w-6 h-6" />
      </Button>
    </div>
  );
};
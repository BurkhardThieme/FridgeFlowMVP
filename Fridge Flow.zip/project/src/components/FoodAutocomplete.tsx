import React, { useState, useRef, useEffect } from 'react';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { searchFoodSuggestions, FoodSuggestion } from '../data/foodDatabase';
import { Search, Plus } from 'lucide-react';

interface FoodAutocompleteProps {
  value: string;
  onChange: (value: string) => void;
  onSuggestionSelect: (suggestion: FoodSuggestion) => void;
  placeholder?: string;
  className?: string;
}

export const FoodAutocomplete: React.FC<FoodAutocompleteProps> = ({
  value,
  onChange,
  onSuggestionSelect,
  placeholder = "Lebensmittel eingeben...",
  className = ""
}) => {
  const [suggestions, setSuggestions] = useState<FoodSuggestion[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(-1);
  const inputRef = useRef<HTMLInputElement>(null);
  const suggestionsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (value.length >= 2) {
      const results = searchFoodSuggestions(value, 6);
      setSuggestions(results);
      setShowSuggestions(results.length > 0);
      setSelectedIndex(-1);
    } else {
      setSuggestions([]);
      setShowSuggestions(false);
    }
  }, [value]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onChange(e.target.value);
  };

  const handleSuggestionClick = (suggestion: FoodSuggestion) => {
    onSuggestionSelect(suggestion);
    setShowSuggestions(false);
    setSelectedIndex(-1);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (!showSuggestions) return;

    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault();
        setSelectedIndex(prev => 
          prev < suggestions.length - 1 ? prev + 1 : prev
        );
        break;
      case 'ArrowUp':
        e.preventDefault();
        setSelectedIndex(prev => prev > 0 ? prev - 1 : -1);
        break;
      case 'Enter':
        e.preventDefault();
        if (selectedIndex >= 0 && selectedIndex < suggestions.length) {
          handleSuggestionClick(suggestions[selectedIndex]);
        }
        break;
      case 'Escape':
        setShowSuggestions(false);
        setSelectedIndex(-1);
        break;
    }
  };

  const handleBlur = () => {
    // Delay hiding suggestions to allow for clicks
    setTimeout(() => {
      setShowSuggestions(false);
      setSelectedIndex(-1);
    }, 200);
  };

  const handleFocus = () => {
    if (suggestions.length > 0) {
      setShowSuggestions(true);
    }
  };

  return (
    <div className="relative">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
        <Input
          ref={inputRef}
          value={value}
          onChange={handleInputChange}
          onKeyDown={handleKeyDown}
          onBlur={handleBlur}
          onFocus={handleFocus}
          placeholder={placeholder}
          className={`pl-10 ${className}`}
          autoComplete="off"
        />
      </div>

      {showSuggestions && suggestions.length > 0 && (
        <div
          ref={suggestionsRef}
          className="absolute top-full left-0 right-0 bg-white border-2 border-gray-200 rounded-2xl shadow-2xl mt-2 max-h-80 overflow-y-auto"
          style={{ 
            position: 'absolute',
            zIndex: 99999,
            boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25), 0 0 0 1px rgba(0, 0, 0, 0.05)'
          }}
        >
          <div className="p-2">
            <div className="text-xs font-bold text-gray-500 uppercase tracking-wider px-3 py-2">
              Vorschläge ({suggestions.length})
            </div>
            {suggestions.map((suggestion, index) => (
              <button
                key={`${suggestion.name}-${index}`}
                onClick={() => handleSuggestionClick(suggestion)}
                className={`w-full flex items-center space-x-3 p-3 rounded-xl transition-all duration-200 text-left ${
                  index === selectedIndex
                    ? 'bg-blue-100 border-2 border-blue-300'
                    : 'hover:bg-gray-50 border-2 border-transparent'
                }`}
              >
                {/* Food Image */}
                <div className="w-12 h-12 rounded-xl overflow-hidden bg-gray-100 flex-shrink-0 shadow-sm">
                  <img
                    src={suggestion.image}
                    alt={suggestion.name}
                    className="w-full h-full object-cover"
                    loading="lazy"
                  />
                </div>

                {/* Food Info */}
                <div className="flex-1 min-w-0">
                  <h4 className="font-bold text-gray-900 truncate">
                    {suggestion.name}
                  </h4>
                  <p className="text-sm text-gray-600 font-medium">
                    {suggestion.defaultQuantity} {suggestion.defaultUnit} • {suggestion.category}
                  </p>
                  <p className="text-xs text-gray-500">
                    Haltbar: {suggestion.defaultExpiryDays} Tage
                  </p>
                </div>

                {/* Add Icon */}
                <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                  <Plus className="w-4 h-4 text-green-600" />
                </div>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
import { useState, useEffect } from 'react';
import { ShoppingItem } from '../types';

const STORAGE_KEY = 'shopping-list';

export const useShoppingList = () => {
  const [items, setItems] = useState<ShoppingItem[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);

  // Load data on mount
  useEffect(() => {
    console.log('🛒 Loading shopping list from localStorage...');
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      console.log('✅ Found stored shopping data:', stored);
      try {
        const parsedItems = JSON.parse(stored);
        console.log('✅ Parsed shopping items:', parsedItems);
        setItems(parsedItems);
      } catch (error) {
        console.error('❌ Error parsing stored shopping data:', error);
        setItems([]);
      }
    } else {
      console.log('ℹ️ No stored shopping data found');
      setItems([]);
    }
    setIsLoaded(true);
  }, []);

  // Save to localStorage whenever items change (but only after initial load)
  useEffect(() => {
    if (!isLoaded) return; // Don't save during initial load
    
    console.log('💾 Saving shopping list to localStorage:', items);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
      console.log('✅ Successfully saved shopping list to localStorage');
    } catch (error) {
      console.error('❌ Error saving shopping list to localStorage:', error);
    }
  }, [items, isLoaded]);

  const addItem = (item: Omit<ShoppingItem, 'id' | 'isCompleted'>) => {
    console.log('🛒➕ Adding new shopping item:', item);
    const newItem: ShoppingItem = {
      ...item,
      id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
      isCompleted: false,
    };
    console.log('✅ Created new shopping item with ID:', newItem);
    setItems(prev => {
      const updated = [...prev, newItem];
      console.log('📝 Updated shopping items array:', updated);
      
      // Dispatch custom event for navigation
      window.dispatchEvent(new CustomEvent('shoppingListUpdated'));
      
      return updated;
    });
  };

  const toggleItem = (id: string) => {
    console.log('🔄 Toggling shopping item:', id);
    setItems(prev => prev.map(item => 
      item.id === id ? { ...item, isCompleted: !item.isCompleted } : item
    ));
  };

  const removeItem = (id: string) => {
    console.log('🗑️ Removing shopping item:', id);
    setItems(prev => prev.filter(item => item.id !== id));
  };

  const clearCompleted = () => {
    console.log('🧹 Clearing completed shopping items');
    setItems(prev => prev.filter(item => !item.isCompleted));
  };

  return {
    items,
    addItem,
    toggleItem,
    removeItem,
    clearCompleted,
    isLoaded,
  };
};
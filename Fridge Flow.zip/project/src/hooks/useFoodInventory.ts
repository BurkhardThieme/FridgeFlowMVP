import { useState, useEffect } from 'react';
import { FoodItem } from '../types';

const STORAGE_KEY = 'food-inventory';

export const useFoodInventory = () => {
  const [items, setItems] = useState<FoodItem[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);

  // Load data on mount
  useEffect(() => {
    console.log('🔄 Loading food inventory from localStorage...');
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      console.log('✅ Found stored data:', stored);
      try {
        const parsedItems = JSON.parse(stored).map((item: any) => ({
          ...item,
          expiryDate: new Date(item.expiryDate),
          addedDate: new Date(item.addedDate),
        }));
        console.log('✅ Parsed items:', parsedItems);
        setItems(parsedItems);
      } catch (error) {
        console.error('❌ Error parsing stored data:', error);
        initializeSampleData();
      }
    } else {
      console.log('ℹ️ No stored data found, initializing with sample data');
      initializeSampleData();
    }
    setIsLoaded(true);
  }, []);

  const initializeSampleData = () => {
    const sampleItems: FoodItem[] = [
      {
        id: '1',
        name: 'Bananen',
        quantity: '1.2',
        unit: 'kg',
        expiryDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000),
        category: 'Obst',
        image: 'https://images.pexels.com/photos/2872755/pexels-photo-2872755.jpeg?auto=compress&cs=tinysrgb&w=400',
        addedDate: new Date(),
        isExpiringSoon: false,
      },
      {
        id: '2',
        name: 'Milch',
        quantity: '1',
        unit: 'L',
        expiryDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000),
        category: 'Milchprodukte',
        image: 'https://images.pexels.com/photos/248412/pexels-photo-248412.jpeg?auto=compress&cs=tinysrgb&w=400',
        addedDate: new Date(),
        isExpiringSoon: true,
      },
      {
        id: '3',
        name: 'Tomaten',
        quantity: '500',
        unit: 'g',
        category: 'Gemüse',
        expiryDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
        image: 'https://images.pexels.com/photos/533280/pexels-photo-533280.jpeg?auto=compress&cs=tinysrgb&w=400',
        addedDate: new Date(),
        isExpiringSoon: false,
      },
    ];
    console.log('🔧 Initializing with sample data:', sampleItems);
    setItems(sampleItems);
    // Save sample data immediately
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(sampleItems));
      console.log('✅ Sample data saved to localStorage');
    } catch (error) {
      console.error('❌ Error saving sample data:', error);
    }
  };

  // Save to localStorage whenever items change (but only after initial load)
  useEffect(() => {
    if (!isLoaded) return; // Don't save during initial load
    
    console.log('💾 Saving food inventory to localStorage:', items);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
      console.log('✅ Successfully saved to localStorage');
    } catch (error) {
      console.error('❌ Error saving to localStorage:', error);
    }
  }, [items, isLoaded]);

  // Helper function to normalize item names for comparison
  const normalizeItemName = (name: string): string => {
    return name.toLowerCase()
      .trim()
      .replace(/ä/g, 'ae')
      .replace(/ö/g, 'oe')
      .replace(/ü/g, 'ue')
      .replace(/ß/g, 'ss')
      .replace(/[^a-z0-9]/g, '');
  };

  // Helper function to check if two items are the same product
  const isSameProduct = (item1: { name: string; category: string; unit: string }, item2: { name: string; category: string; unit: string }): boolean => {
    const name1 = normalizeItemName(item1.name);
    const name2 = normalizeItemName(item2.name);
    
    // Direct name match
    if (name1 === name2) return true;
    
    // Check for common variations
    const variations: { [key: string]: string[] } = {
      'apfel': ['apfel', 'aepfel'],
      'aepfel': ['apfel', 'aepfel'],
      'tomate': ['tomate', 'tomaten'],
      'tomaten': ['tomate', 'tomaten'],
      'zwiebel': ['zwiebel', 'zwiebeln'],
      'zwiebeln': ['zwiebel', 'zwiebeln'],
      'karotte': ['karotte', 'karotten', 'moehre', 'moehren'],
      'karotten': ['karotte', 'karotten', 'moehre', 'moehren'],
      'moehre': ['karotte', 'karotten', 'moehre', 'moehren'],
      'moehren': ['karotte', 'karotten', 'moehre', 'moehren'],
      'nudel': ['nudel', 'nudeln', 'pasta'],
      'nudeln': ['nudel', 'nudeln', 'pasta'],
      'pasta': ['nudel', 'nudeln', 'pasta'],
      'haehnchen': ['haehnchen', 'haehnchenbrust', 'huhn', 'huehnchen'],
      'haehnchenbrust': ['haehnchen', 'haehnchenbrust', 'huhn', 'huehnchen'],
      'huhn': ['haehnchen', 'haehnchenbrust', 'huhn', 'huehnchen'],
      'huehnchen': ['haehnchen', 'haehnchenbrust', 'huhn', 'huehnchen'],
      'olivenoel': ['olivenoel', 'oel'],
      'oel': ['olivenoel', 'oel'],
    };

    const variations1 = variations[name1] || [name1];
    const variations2 = variations[name2] || [name2];
    
    // Check if any variation matches
    const hasVariationMatch = variations1.some(v1 => variations2.includes(v1));
    
    // Also check category and unit compatibility for better matching
    const categoryMatch = item1.category === item2.category;
    const unitCompatible = areUnitsCompatible(item1.unit, item2.unit);
    
    return hasVariationMatch && categoryMatch && unitCompatible;
  };

  // Helper function to check if units are compatible for merging
  const areUnitsCompatible = (unit1: string, unit2: string): boolean => {
    const weightUnits = ['g', 'kg'];
    const volumeUnits = ['ml', 'L'];
    const countUnits = ['Stück', 'Packung', 'Dose', 'Flasche', 'Beutel', 'Glas'];
    
    const isInSameGroup = (units: string[]) => units.includes(unit1) && units.includes(unit2);
    
    return unit1 === unit2 || 
           isInSameGroup(weightUnits) || 
           isInSameGroup(volumeUnits) || 
           isInSameGroup(countUnits);
  };

  // Helper function to convert units to a common base for addition
  const convertToBaseUnit = (quantity: string, unit: string): { value: number; baseUnit: string } => {
    const numericQuantity = parseFloat(quantity) || 0;
    
    // Weight conversions to grams
    if (unit === 'kg') return { value: numericQuantity * 1000, baseUnit: 'g' };
    if (unit === 'g') return { value: numericQuantity, baseUnit: 'g' };
    
    // Volume conversions to ml
    if (unit === 'L') return { value: numericQuantity * 1000, baseUnit: 'ml' };
    if (unit === 'ml') return { value: numericQuantity, baseUnit: 'ml' };
    
    // Count units stay as is
    return { value: numericQuantity, baseUnit: unit };
  };

  // Helper function to convert back to preferred unit
  const convertFromBaseUnit = (value: number, baseUnit: string): { quantity: string; unit: string } => {
    // Convert large gram amounts to kg
    if (baseUnit === 'g' && value >= 1000) {
      return { quantity: (value / 1000).toString(), unit: 'kg' };
    }
    
    // Convert large ml amounts to L
    if (baseUnit === 'ml' && value >= 1000) {
      return { quantity: (value / 1000).toString(), unit: 'L' };
    }
    
    return { quantity: value.toString(), unit: baseUnit };
  };

  const addItem = (item: Omit<FoodItem, 'id' | 'addedDate' | 'isExpiringSoon'>) => {
    console.log('➕ Adding new item:', item);
    
    // Check if a similar item already exists
    const existingItemIndex = items.findIndex(existingItem => 
      isSameProduct(existingItem, item)
    );

    if (existingItemIndex !== -1) {
      console.log('🔄 Found existing similar item, merging quantities...');
      const existingItem = items[existingItemIndex];
      
      // Convert both quantities to base units
      const existing = convertToBaseUnit(existingItem.quantity, existingItem.unit);
      const newItem = convertToBaseUnit(item.quantity, item.unit);
      
      if (existing.baseUnit === newItem.baseUnit) {
        // Merge quantities
        const totalValue = existing.value + newItem.value;
        const converted = convertFromBaseUnit(totalValue, existing.baseUnit);
        
        // Update the existing item with merged quantity and earliest expiry date
        const updatedItem: FoodItem = {
          ...existingItem,
          quantity: converted.quantity,
          unit: converted.unit,
          expiryDate: new Date(Math.min(existingItem.expiryDate.getTime(), item.expiryDate.getTime())),
          image: item.image || existingItem.image, // Use new image if provided
          isExpiringSoon: isExpiringSoon(new Date(Math.min(existingItem.expiryDate.getTime(), item.expiryDate.getTime()))),
        };
        
        console.log('✅ Merged item:', updatedItem);
        
        setItems(prev => {
          const updated = [...prev];
          updated[existingItemIndex] = updatedItem;
          console.log('📝 Updated items array with merged item:', updated);
          return updated;
        });
        
        return; // Exit early, item was merged
      }
    }

    // If no similar item found or units incompatible, add as new item
    const newItem: FoodItem = {
      ...item,
      id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
      addedDate: new Date(),
      isExpiringSoon: isExpiringSoon(item.expiryDate),
    };
    console.log('✅ Created new item with ID:', newItem);
    setItems(prev => {
      const updated = [...prev, newItem];
      console.log('📝 Updated items array:', updated);
      return updated;
    });
  };

  const removeItem = (id: string) => {
    console.log('🗑️ Removing item:', id);
    setItems(prev => prev.filter(item => item.id !== id));
  };

  const consumeQuantity = (id: string, consumedQuantity: number, newQuantity: string) => {
    console.log('☕ Consuming quantity:', { id, consumedQuantity, newQuantity });
    
    const numericNewQuantity = parseFloat(newQuantity);
    
    if (numericNewQuantity <= 0) {
      // If quantity is 0 or less, remove the item completely
      console.log('🗑️ Quantity is 0, removing item completely');
      removeItem(id);
    } else {
      // Update the quantity
      const updatedItem = items.find(item => item.id === id);
      if (updatedItem) {
        const updated = {
          ...updatedItem,
          quantity: newQuantity,
          isExpiringSoon: isExpiringSoon(updatedItem.expiryDate)
        };
        setItems(prev => prev.map(item => item.id === id ? updated : item));
      }
    }
  };

  const isExpiringSoon = (expiryDate: Date) => {
    const threeDaysFromNow = new Date();
    threeDaysFromNow.setDate(threeDaysFromNow.getDate() + 3);
    return expiryDate <= threeDaysFromNow;
  };

  const getExpiringSoonItems = () => {
    return items.filter(item => isExpiringSoon(item.expiryDate));
  };

  // Sort items by expiry date (soonest first) and then by name
  const getSortedItems = () => {
    return [...items].sort((a, b) => {
      // First sort by expiry date
      const aExpiry = new Date(a.expiryDate).getTime();
      const bExpiry = new Date(b.expiryDate).getTime();
      
      if (aExpiry !== bExpiry) {
        return aExpiry - bExpiry;
      }
      
      // If expiry dates are the same, sort by name
      return a.name.localeCompare(b.name);
    });
  };

  return {
    items: getSortedItems(),
    addItem,
    removeItem,
    consumeQuantity,
    getExpiringSoonItems,
    isLoaded,
  };
};
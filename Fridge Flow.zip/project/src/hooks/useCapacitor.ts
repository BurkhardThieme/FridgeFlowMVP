import { useEffect, useState } from 'react';
import { Capacitor } from '@capacitor/core';
import { setStatusBarStyle, setStatusBarColor, hideSplashScreen } from '../capacitor-plugins';

export const useCapacitor = () => {
  const [isNative, setIsNative] = useState(false);
  const [platform, setPlatform] = useState<string>('web');

  useEffect(() => {
    const checkPlatform = () => {
      const native = Capacitor.isNativePlatform();
      const currentPlatform = Capacitor.getPlatform();
      
      setIsNative(native);
      setPlatform(currentPlatform);
      
      console.log('Platform:', currentPlatform, 'Native:', native);
    };

    checkPlatform();

    // Initialize native features
    if (Capacitor.isNativePlatform()) {
      initializeNativeFeatures();
    }
  }, []);

  const initializeNativeFeatures = async () => {
    try {
      // Set status bar style
      await setStatusBarStyle();
      await setStatusBarColor('#16a34a');
      
      // Hide splash screen after a delay
      setTimeout(async () => {
        await hideSplashScreen();
      }, 1500);
      
      console.log('Native features initialized');
    } catch (error) {
      console.error('Error initializing native features:', error);
    }
  };

  return {
    isNative,
    platform,
    isAndroid: platform === 'android',
    isIOS: platform === 'ios',
    isWeb: platform === 'web'
  };
};
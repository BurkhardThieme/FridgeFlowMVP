import { Camera, CameraResultType, CameraSource } from '@capacitor/camera';
import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';
import { Haptics, ImpactStyle } from '@capacitor/haptics';
import { StatusBar, Style } from '@capacitor/status-bar';
import { SplashScreen } from '@capacitor/splash-screen';

// Camera functionality
export const takePicture = async () => {
  try {
    const image = await Camera.getPhoto({
      quality: 90,
      allowEditing: false,
      resultType: CameraResultType.Uri,
      source: CameraSource.Camera
    });
    
    return image.webPath;
  } catch (error) {
    console.error('Error taking picture:', error);
    throw error;
  }
};

export const pickFromGallery = async () => {
  try {
    const image = await Camera.getPhoto({
      quality: 90,
      allowEditing: false,
      resultType: CameraResultType.Uri,
      source: CameraSource.Photos
    });
    
    return image.webPath;
  } catch (error) {
    console.error('Error picking from gallery:', error);
    throw error;
  }
};

// Haptic feedback
export const triggerHaptic = async (style: ImpactStyle = ImpactStyle.Medium) => {
  try {
    await Haptics.impact({ style });
  } catch (error) {
    console.log('Haptics not available:', error);
  }
};

// Status bar management
export const setStatusBarStyle = async (style: Style = Style.Dark) => {
  try {
    await StatusBar.setStyle({ style });
  } catch (error) {
    console.log('Status bar not available:', error);
  }
};

export const setStatusBarColor = async (color: string) => {
  try {
    await StatusBar.setBackgroundColor({ color });
  } catch (error) {
    console.log('Status bar color not available:', error);
  }
};

// File system operations
export const saveToDevice = async (data: string, filename: string) => {
  try {
    await Filesystem.writeFile({
      path: filename,
      data: data,
      directory: Directory.Documents,
      encoding: Encoding.UTF8
    });
    
    return true;
  } catch (error) {
    console.error('Error saving file:', error);
    return false;
  }
};

export const readFromDevice = async (filename: string) => {
  try {
    const result = await Filesystem.readFile({
      path: filename,
      directory: Directory.Documents,
      encoding: Encoding.UTF8
    });
    
    return result.data;
  } catch (error) {
    console.error('Error reading file:', error);
    return null;
  }
};

// Splash screen management
export const hideSplashScreen = async () => {
  try {
    await SplashScreen.hide();
  } catch (error) {
    console.log('Splash screen not available:', error);
  }
};
import React, { useState } from 'react';
import { StatusBar } from '../components/StatusBar';
import { Button } from '../components/ui/button';
import { 
  User, 
  Settings, 
  FileText, 
  Shield, 
  HelpCircle, 
  Mail, 
  ChevronRight,
  Bell,
  Smartphone,
  Globe,
  Trash2,
  Download,
  Upload
} from 'lucide-react';

export const AccountScreen: React.FC = () => {
  const [notifications, setNotifications] = useState(true);

  const menuItems = [
    {
      category: 'Account',
      items: [
        {
          icon: User,
          label: 'Profil bearbeiten',
          description: 'Name, E-Mail und Foto ändern',
          action: () => console.log('Profile clicked'),
        },
        {
          icon: Bell,
          label: 'Benachrichtigungen',
          description: notifications ? 'Aktiviert' : 'Deaktiviert',
          action: () => setNotifications(!notifications),
          toggle: true,
          value: notifications,
        },
      ],
    },
    {
      category: 'App-Einstellungen',
      items: [
        {
          icon: Smartphone,
          label: 'App-Einstellungen',
          description: 'Sprache, Design und mehr',
          action: () => console.log('App settings clicked'),
        },
        {
          icon: Download,
          label: 'Daten exportieren',
          description: 'Ihre Daten herunterladen',
          action: () => console.log('Export data clicked'),
        },
        {
          icon: Upload,
          label: 'Daten importieren',
          description: 'Daten aus Backup wiederherstellen',
          action: () => console.log('Import data clicked'),
        },
      ],
    },
    {
      category: 'Support & Rechtliches',
      items: [
        {
          icon: HelpCircle,
          label: 'Hilfe & Support',
          description: 'FAQ und Kontakt',
          action: () => console.log('Help clicked'),
        },
        {
          icon: Mail,
          label: 'Feedback senden',
          description: 'Verbesserungsvorschläge mitteilen',
          action: () => console.log('Feedback clicked'),
        },
        {
          icon: FileText,
          label: 'Allgemeine Geschäftsbedingungen',
          description: 'AGB lesen',
          action: () => window.open('https://example.com/agb', '_blank'),
        },
        {
          icon: Shield,
          label: 'Datenschutzerklärung',
          description: 'Datenschutz und Privatsphäre',
          action: () => window.open('https://example.com/datenschutz', '_blank'),
        },
        {
          icon: FileText,
          label: 'Impressum',
          description: 'Rechtliche Informationen',
          action: () => window.open('https://example.com/impressum', '_blank'),
        },
      ],
    },
    {
      category: 'Daten',
      items: [
        {
          icon: Trash2,
          label: 'Alle Daten löschen',
          description: 'Vorräte und Einkaufsliste zurücksetzen',
          action: () => {
            if (window.confirm('Möchten Sie wirklich alle Daten löschen? Diese Aktion kann nicht rückgängig gemacht werden.')) {
              localStorage.removeItem('food-inventory');
              localStorage.removeItem('shopping-list');
              window.location.reload();
            }
          },
          destructive: true,
        },
      ],
    },
  ];

  return (
    <div className="h-full flex flex-col bg-gradient-to-br from-fridge-blue-50 to-fridge-green-50">
      <StatusBar />

      {/* Header */}
      <div className="px-6 py-6 bg-white/80 backdrop-blur-sm border-b border-white/20">
        <h1 className="text-3xl font-bold text-fridge-navy-900 tracking-tight">Account</h1>
        <p className="text-sm text-fridge-navy-600 font-medium">Einstellungen und Informationen</p>
      </div>

      {/* Profile Section */}
      <div className="px-6 py-6 bg-white/80 backdrop-blur-sm border-b border-white/20">
        <div className="flex items-center space-x-4">
          <div className="w-20 h-20 bg-gradient-to-br from-fridge-blue-400 to-fridge-green-600 rounded-3xl flex items-center justify-center shadow-lg">
            <User className="w-10 h-10 text-white" />
          </div>
          <div className="flex-1">
            <h2 className="text-2xl font-bold text-fridge-navy-900">Benutzer</h2>
            <p className="text-base text-fridge-navy-600 font-medium">benutzer@example.com</p>
          </div>
        </div>
      </div>

      {/* Menu Items */}
      <div className="flex-1 overflow-y-auto">
        {menuItems.map((section, sectionIndex) => (
          <div key={sectionIndex} className="py-6">
            <h3 className="px-6 text-sm font-bold text-fridge-navy-500 uppercase tracking-wider mb-4">
              {section.category}
            </h3>
            <div className="space-y-2 px-6">
              {section.items.map((item, itemIndex) => {
                const Icon = item.icon;
                
                return (
                  <button
                    key={itemIndex}
                    onClick={item.action}
                    className={`w-full flex items-center space-x-4 p-4 rounded-3xl transition-all duration-200 shadow-sm ${
                      item.destructive 
                        ? 'bg-red-50/80 hover:bg-red-100/80 active:bg-red-200/80 border-2 border-red-200' 
                        : 'bg-white/80 hover:bg-white/90 active:bg-white border-2 border-fridge-blue-200 hover:border-fridge-blue-300'
                    } backdrop-blur-sm active:scale-98`}
                  >
                    <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shadow-md ${
                      item.destructive 
                        ? 'bg-red-500' 
                        : 'bg-fridge-blue-100'
                    }`}>
                      <Icon className={`w-6 h-6 ${
                        item.destructive 
                          ? 'text-white' 
                          : 'text-fridge-blue-600'
                      }`} />
                    </div>
                    
                    <div className="flex-1 text-left">
                      <p className={`font-bold text-base ${
                        item.destructive 
                          ? 'text-red-900' 
                          : 'text-fridge-navy-900'
                      }`}>
                        {item.label}
                      </p>
                      <p className={`text-sm font-medium ${
                        item.destructive 
                          ? 'text-red-600' 
                          : 'text-fridge-navy-600'
                      }`}>
                        {item.description}
                      </p>
                    </div>

                    {item.toggle ? (
                      <div className={`w-14 h-8 rounded-full transition-colors shadow-inner ${
                        item.value ? 'bg-fridge-green-500' : 'bg-gray-300'
                      }`}>
                        <div className={`w-6 h-6 bg-white rounded-full shadow-lg transition-transform mt-1 ${
                          item.value ? 'translate-x-7' : 'translate-x-1'
                        }`} />
                      </div>
                    ) : (
                      <ChevronRight className="w-6 h-6 text-fridge-navy-400" />
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        ))}

        {/* App Version */}
        <div className="px-6 py-8 text-center">
          <div className="bg-white/80 backdrop-blur-sm rounded-3xl p-6 shadow-sm border-2 border-fridge-blue-200">
            <p className="text-base font-bold text-fridge-navy-700">
              Fridge Flow App
            </p>
            <p className="text-sm text-fridge-navy-500 mt-1 font-medium">
              Version 1.0.0
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
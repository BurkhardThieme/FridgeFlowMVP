import React, { useState, useMemo, useEffect } from 'react';
import { RecipeCard } from '../components/RecipeCard';
import { RecipeDetailDialog } from '../components/RecipeDetailDialog';
import { StatusBar } from '../components/StatusBar';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { useFoodInventory } from '../hooks/useFoodInventory';
import { useShoppingList } from '../hooks/useShoppingList';
import { Recipe } from '../types';
import { Search, ChefHat, Filter, X, CheckCircle, Clock, Star, Users, Utensils, AlertTriangle } from 'lucide-react';

const sampleRecipes: Recipe[] = [
  {
    id: '1',
    name: 'Bananen-Smoothie',
    ingredients: ['2 Bananen', '200ml Milch', '1 EL Honig'],
    instructions: [
      'Bananen schälen und in Stücke schneiden',
      'Alle Zutaten in den Mixer geben',
      'Bis zur gewünschten Konsistenz mixen',
      'In Gläser füllen und sofort servieren',
    ],
    image: 'https://images.pexels.com/photos/1092730/pexels-photo-1092730.jpeg?auto=compress&cs=tinysrgb&w=400',
    cookingTime: 5,
    difficulty: 'easy',
  },
  {
    id: '2',
    name: 'Tomaten-Mozzarella-Salat',
    ingredients: ['3 Tomaten', '200g Mozzarella', '10 Basilikumblätter', '3 EL Olivenöl'],
    instructions: [
      'Tomaten und Mozzarella in Scheiben schneiden',
      'Abwechselnd auf einem Teller anrichten',
      'Mit Basilikum und Olivenöl garnieren',
      'Mit Salz und Pfeffer würzen',
    ],
    image: 'https://images.pexels.com/photos/1059905/pexels-photo-1059905.jpeg?auto=compress&cs=tinysrgb&w=400',
    cookingTime: 10,
    difficulty: 'easy',
  },
  {
    id: '3',
    name: 'Milchreis mit Zimt',
    ingredients: ['500ml Milch', '100g Reis', '2 EL Zucker', '1 TL Zimt'],
    instructions: [
      'Milch in einem Topf erhitzen',
      'Reis hinzufügen und köcheln lassen',
      'Regelmäßig umrühren, bis der Reis weich ist',
      'Mit Zucker und Zimt abschmecken',
      'Warm oder kalt servieren',
    ],
    image: 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=400',
    cookingTime: 25,
    difficulty: 'medium',
  },
  {
    id: '4',
    name: 'Apfel-Zimt-Kuchen',
    ingredients: ['4 Äpfel', '300g Mehl', '3 Eier', '200g Butter', '150g Zucker', '2 TL Zimt'],
    instructions: [
      'Äpfel schälen und würfeln',
      'Teig aus Mehl, Eiern, Butter und Zucker zubereiten',
      'Äpfel und Zimt unterheben',
      'In eine gefettete Form geben',
      'Im Ofen bei 180°C für 45 Minuten backen',
    ],
    image: 'https://images.pexels.com/photos/1070850/pexels-photo-1070850.jpeg?auto=compress&cs=tinysrgb&w=400',
    cookingTime: 60,
    difficulty: 'medium',
  },
  {
    id: '5',
    name: 'Gemüse-Pfanne',
    ingredients: ['2 Paprika', '1 Zwiebel', '3 Karotten', '3 EL Olivenöl', 'Gewürze nach Geschmack'],
    instructions: [
      'Gemüse waschen und schneiden',
      'Olivenöl in der Pfanne erhitzen',
      'Zwiebeln zuerst anbraten',
      'Karotten und Paprika hinzufügen',
      'Mit Gewürzen abschmecken und servieren',
    ],
    image: 'https://images.pexels.com/photos/1640770/pexels-photo-1640770.jpeg?auto=compress&cs=tinysrgb&w=400',
    cookingTime: 20,
    difficulty: 'easy',
  },
  {
    id: '6',
    name: 'Hähnchen mit Reis',
    ingredients: ['400g Hähnchenbrust', '200g Reis', '1 Zwiebel', 'Gewürze nach Geschmack'],
    instructions: [
      'Hähnchen würzen und anbraten',
      'Reis nach Packungsanweisung kochen',
      'Zwiebeln in einer separaten Pfanne dünsten',
      'Hähnchen in Streifen schneiden',
      'Alles zusammen anrichten und servieren',
    ],
    image: 'https://images.pexels.com/photos/2338407/pexels-photo-2338407.jpeg?auto=compress&cs=tinysrgb&w=400',
    cookingTime: 35,
    difficulty: 'medium',
  },
  {
    id: '7',
    name: 'Nudeln mit Käse',
    ingredients: ['300g Nudeln', '150g Käse', '50g Butter', '200ml Milch'],
    instructions: [
      'Nudeln in Salzwasser kochen',
      'Butter in einer Pfanne schmelzen',
      'Milch hinzufügen und erwärmen',
      'Käse einrühren bis eine cremige Sauce entsteht',
      'Nudeln mit der Käse-Sauce vermischen',
    ],
    image: 'https://images.pexels.com/photos/1437267/pexels-photo-1437267.jpeg?auto=compress&cs=tinysrgb&w=400',
    cookingTime: 15,
    difficulty: 'easy',
  },
  {
    id: '8',
    name: 'Gurken-Salat',
    ingredients: ['2 Gurken', '1 Zwiebel', '3 EL Essig', '2 EL Öl', '1 Bund Dill'],
    instructions: [
      'Gurken waschen und in Scheiben schneiden',
      'Zwiebeln fein hacken',
      'Dressing aus Essig, Öl und gehacktem Dill zubereiten',
      'Gurken und Zwiebeln mit dem Dressing marinieren',
      'Mindestens 30 Minuten ziehen lassen',
    ],
    image: 'https://images.pexels.com/photos/37528/cucumber-salad-food-healthy-37528.jpeg?auto=compress&cs=tinysrgb&w=400',
    cookingTime: 10,
    difficulty: 'easy',
  },
  // 10 neue Rezepte hinzugefügt
  {
    id: '9',
    name: 'Rührei mit Käse',
    ingredients: ['4 Eier', '100g Käse', '2 EL Butter', '100ml Milch', 'Salz und Pfeffer'],
    instructions: [
      'Eier in einer Schüssel verquirlen',
      'Milch, Salz und Pfeffer hinzufügen',
      'Butter in der Pfanne erhitzen',
      'Eimasse hinzugeben und bei mittlerer Hitze stocken lassen',
      'Käse darüber streuen und schmelzen lassen',
      'Sofort servieren',
    ],
    image: 'https://images.pexels.com/photos/824635/pexels-photo-824635.jpeg?auto=compress&cs=tinysrgb&w=400',
    cookingTime: 8,
    difficulty: 'easy',
  },
  {
    id: '10',
    name: 'Kartoffel-Gratin',
    ingredients: ['1kg Kartoffeln', '300ml Milch', '200g Käse', '2 EL Butter', 'Muskatnuss'],
    instructions: [
      'Kartoffeln schälen und in dünne Scheiben schneiden',
      'Auflaufform mit Butter einfetten',
      'Kartoffeln schichtweise einlegen',
      'Mit Milch übergießen und würzen',
      'Käse darüber streuen',
      'Bei 200°C für 45 Minuten backen',
    ],
    image: 'https://images.pexels.com/photos/5949888/pexels-photo-5949888.jpeg?auto=compress&cs=tinysrgb&w=400',
    cookingTime: 60,
    difficulty: 'medium',
  },
  {
    id: '11',
    name: 'Obstsalat',
    ingredients: ['2 Äpfel', '2 Bananen', '1 Orange', '200g Trauben', '2 EL Honig'],
    instructions: [
      'Äpfel waschen, entkernen und würfeln',
      'Bananen schälen und in Scheiben schneiden',
      'Orange schälen und filetieren',
      'Trauben waschen und halbieren',
      'Alles in einer Schüssel vermischen',
      'Mit Honig süßen und servieren',
    ],
    image: 'https://images.pexels.com/photos/1092730/pexels-photo-1092730.jpeg?auto=compress&cs=tinysrgb&w=400',
    cookingTime: 15,
    difficulty: 'easy',
  },
  {
    id: '12',
    name: 'Spaghetti Bolognese',
    ingredients: ['400g Spaghetti', '500g Hackfleisch', '1 Zwiebel', '2 Karotten', '400g Tomaten', '3 EL Olivenöl'],
    instructions: [
      'Zwiebeln und Karotten fein würfeln',
      'Olivenöl in einer Pfanne erhitzen',
      'Zwiebeln und Karotten anbraten',
      'Hackfleisch hinzufügen und krümelig braten',
      'Tomaten hinzufügen und 20 Minuten köcheln',
      'Spaghetti kochen und mit der Sauce servieren',
    ],
    image: 'https://images.pexels.com/photos/4518843/pexels-photo-4518843.jpeg?auto=compress&cs=tinysrgb&w=400',
    cookingTime: 30,
    difficulty: 'medium',
  },
  {
    id: '13',
    name: 'Pfannkuchen',
    ingredients: ['250g Mehl', '3 Eier', '400ml Milch', '1 Prise Salz', '2 EL Zucker', 'Butter zum Braten'],
    instructions: [
      'Mehl, Eier, Milch, Salz und Zucker zu einem glatten Teig verrühren',
      '30 Minuten quellen lassen',
      'Butter in der Pfanne erhitzen',
      'Teig portionsweise in die Pfanne geben',
      'Von beiden Seiten goldbraun backen',
      'Mit Marmelade oder Zucker servieren',
    ],
    image: 'https://images.pexels.com/photos/376464/pexels-photo-376464.jpeg?auto=compress&cs=tinysrgb&w=400',
    cookingTime: 20,
    difficulty: 'easy',
  },
  {
    id: '14',
    name: 'Gemüsesuppe',
    ingredients: ['2 Karotten', '1 Zwiebel', '2 Kartoffeln', '1L Gemüsebrühe', '200g Erbsen', '2 EL Olivenöl'],
    instructions: [
      'Gemüse waschen und würfeln',
      'Olivenöl in einem Topf erhitzen',
      'Zwiebeln glasig dünsten',
      'Karotten und Kartoffeln hinzufügen',
      'Mit Brühe aufgießen und 20 Minuten kochen',
      'Erbsen hinzufügen und weitere 5 Minuten kochen',
    ],
    image: 'https://images.pexels.com/photos/539451/pexels-photo-539451.jpeg?auto=compress&cs=tinysrgb&w=400',
    cookingTime: 30,
    difficulty: 'easy',
  },
  {
    id: '15',
    name: 'Käse-Toast',
    ingredients: ['4 Scheiben Brot', '200g Käse', '2 EL Butter', '1 Tomate'],
    instructions: [
      'Brotscheiben mit Butter bestreichen',
      'Käse darauf verteilen',
      'Tomatenscheiben darauf legen',
      'Im Toaster oder unter dem Grill überbacken',
      'Bis der Käse geschmolzen ist',
      'Heiß servieren',
    ],
    image: 'https://images.pexels.com/photos/461198/pexels-photo-461198.jpeg?auto=compress&cs=tinysrgb&w=400',
    cookingTime: 5,
    difficulty: 'easy',
  },
  {
    id: '16',
    name: 'Hähnchen-Curry',
    ingredients: ['500g Hähnchenbrust', '1 Zwiebel', '400ml Kokosmilch', '2 EL Curry', '1 Paprika', '2 EL Öl'],
    instructions: [
      'Hähnchen in Würfel schneiden',
      'Zwiebeln und Paprika würfeln',
      'Öl in einer Pfanne erhitzen',
      'Hähnchen anbraten und herausnehmen',
      'Gemüse anbraten, Curry hinzufügen',
      'Kokosmilch und Hähnchen hinzufügen, 15 Minuten köcheln',
    ],
    image: 'https://images.pexels.com/photos/2474661/pexels-photo-2474661.jpeg?auto=compress&cs=tinysrgb&w=400',
    cookingTime: 25,
    difficulty: 'medium',
  },
  {
    id: '17',
    name: 'Bananenbrot',
    ingredients: ['3 reife Bananen', '300g Mehl', '2 Eier', '100g Butter', '100g Zucker', '1 TL Backpulver'],
    instructions: [
      'Bananen zerdrücken',
      'Butter schmelzen und abkühlen lassen',
      'Alle Zutaten zu einem Teig verrühren',
      'In eine gefettete Kastenform füllen',
      'Bei 180°C für 50 Minuten backen',
      'Stäbchenprobe machen',
    ],
    image: 'https://images.pexels.com/photos/830894/pexels-photo-830894.jpeg?auto=compress&cs=tinysrgb&w=400',
    cookingTime: 65,
    difficulty: 'medium',
  },
  {
    id: '18',
    name: 'Griechischer Salat',
    ingredients: ['2 Tomaten', '1 Gurke', '1 Zwiebel', '200g Feta', '100g Oliven', '4 EL Olivenöl'],
    instructions: [
      'Tomaten und Gurken würfeln',
      'Zwiebeln in Ringe schneiden',
      'Feta in Würfel schneiden',
      'Alles in einer Schüssel vermischen',
      'Mit Olivenöl und Oregano würzen',
      'Oliven darüber streuen',
    ],
    image: 'https://images.pexels.com/photos/1213710/pexels-photo-1213710.jpeg?auto=compress&cs=tinysrgb&w=400',
    cookingTime: 10,
    difficulty: 'easy',
  },
  {
    id: '19',
    name: 'Mediterrane Nudeln mit Feta und Tomaten',
    ingredients: ['400g Nudeln', '300g Kirschtomaten', '200g Feta', '4 EL Olivenöl'],
    instructions: [
      'Nudeln in Salzwasser nach Packungsanweisung kochen',
      'Kirschtomaten halbieren',
      'Olivenöl in einer großen Pfanne erhitzen',
      'Tomaten in die Pfanne geben und 5 Minuten anbraten',
      'Gekochte Nudeln zur Pfanne geben und vermischen',
      'Feta in Würfel schneiden und vorsichtig unterheben',
      'Mit Salz und Pfeffer abschmecken',
      'Sofort servieren',
    ],
    image: 'https://images.pexels.com/photos/1279330/pexels-photo-1279330.jpeg?auto=compress&cs=tinysrgb&w=400',
    cookingTime: 15,
    difficulty: 'easy',
  },
];

interface RecipesScreenProps {
  highlightedIngredients?: string[];
}

export const RecipesScreen: React.FC<RecipesScreenProps> = ({ highlightedIngredients = [] }) => {
  const { items } = useFoodInventory();
  const { addItem: addToShopping } = useShoppingList();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>('all');
  const [selectedCookingTime, setSelectedCookingTime] = useState<string>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [sortBy, setSortBy] = useState<string>('match');
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);
  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);
  const [isRecipeDialogOpen, setIsRecipeDialogOpen] = useState(false);
  const [showSuccessMessage, setShowSuccessMessage] = useState(false);

  const availableIngredients = items.map(item => item.name);

  // Clear highlighted ingredients when user starts searching or filtering
  useEffect(() => {
    if (searchTerm || selectedDifficulty !== 'all') {
      // User is actively searching/filtering, so we don't need to maintain the highlight
    }
  }, [searchTerm, selectedDifficulty]);

  // Improved ingredient matching function
  const ingredientMatches = (recipeIngredient: string, availableIngredient: string): boolean => {
    const recipe = recipeIngredient.toLowerCase();
    const available = availableIngredient.toLowerCase();
    
    // Direct match
    if (recipe === available) return true;
    
    // Partial matches
    if (recipe.includes(available) || available.includes(recipe)) return true;
    
    // Common ingredient variations
    const variations: { [key: string]: string[] } = {
      'äpfel': ['apfel', 'äpfel'],
      'apfel': ['apfel', 'äpfel'],
      'tomaten': ['tomate', 'tomaten'],
      'tomate': ['tomate', 'tomaten'],
      'zwiebeln': ['zwiebel', 'zwiebeln'],
      'zwiebel': ['zwiebel', 'zwiebeln'],
      'karotten': ['karotte', 'karotten', 'möhre', 'möhren'],
      'karotte': ['karotte', 'karotten', 'möhre', 'möhren'],
      'möhre': ['karotte', 'karotten', 'möhre', 'möhren'],
      'möhren': ['karotte', 'karotten', 'möhre', 'möhren'],
      'paprika': ['paprika', 'paprikaschote'],
      'hähnchenbrust': ['hähnchen', 'hähnchenbrust', 'hühnchen', 'hühnchenbrust'],
      'hähnchen': ['hähnchen', 'hähnchenbrust', 'hühnchen', 'hühnchenbrust'],
      'hühnchen': ['hähnchen', 'hähnchenbrust', 'hühnchen', 'hühnchenbrust'],
      'nudeln': ['nudel', 'nudeln', 'pasta'],
      'nudel': ['nudel', 'nudeln', 'pasta'],
      'pasta': ['nudel', 'nudeln', 'pasta'],
      'mozzarella': ['mozzarella', 'mozarella'],
      'feta': ['feta', 'fetakäse', 'schafskäse'],
    };
    
    // Check variations
    const recipeVariations = variations[recipe] || [recipe];
    const availableVariations = variations[available] || [available];
    
    return recipeVariations.some(rv => 
      availableVariations.some(av => rv === av || rv.includes(av) || av.includes(rv))
    );
  };

  // Get recipe categories
  const getRecipeCategories = () => {
    const categories = new Set<string>();
    sampleRecipes.forEach(recipe => {
      if (recipe.ingredients.some(ing => ing.toLowerCase().includes('fleisch') || ing.toLowerCase().includes('hähnchen') || ing.toLowerCase().includes('hackfleisch'))) {
        categories.add('Fleisch');
      } else if (recipe.ingredients.some(ing => ing.toLowerCase().includes('gemüse') || ing.toLowerCase().includes('salat') || ing.toLowerCase().includes('tomate'))) {
        categories.add('Vegetarisch');
      } else if (recipe.ingredients.some(ing => ing.toLowerCase().includes('kuchen') || ing.toLowerCase().includes('zucker') || ing.toLowerCase().includes('honig'))) {
        categories.add('Süß');
      } else if (recipe.ingredients.some(ing => ing.toLowerCase().includes('suppe') || ing.toLowerCase().includes('brühe'))) {
        categories.add('Suppen');
      } else {
        categories.add('Sonstiges');
      }
    });
    return Array.from(categories).sort();
  };

  // Check if recipe actually uses highlighted ingredients
  const recipeUsesHighlightedIngredients = (recipe: Recipe): boolean => {
    if (highlightedIngredients.length === 0) return false;
    
    return recipe.ingredients.some(ingredient =>
      highlightedIngredients.some(highlighted => 
        ingredientMatches(ingredient, highlighted)
      )
    );
  };

  // Get recipes that actually use highlighted ingredients
  const getMatchingRecipesForHighlighted = (): Recipe[] => {
    if (highlightedIngredients.length === 0) return [];
    
    return sampleRecipes.filter(recipe => recipeUsesHighlightedIngredients(recipe));
  };

  const filteredRecipes = useMemo(() => {
    return sampleRecipes.filter(recipe => {
      const matchesSearch = recipe.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        recipe.ingredients.some(ingredient => 
          ingredient.toLowerCase().includes(searchTerm.toLowerCase())
        );
      
      const matchesDifficulty = selectedDifficulty === 'all' || recipe.difficulty === selectedDifficulty;
      
      const matchesCookingTime = selectedCookingTime === 'all' || 
        (selectedCookingTime === 'quick' && recipe.cookingTime <= 15) ||
        (selectedCookingTime === 'medium' && recipe.cookingTime > 15 && recipe.cookingTime <= 45) ||
        (selectedCookingTime === 'long' && recipe.cookingTime > 45);

      const matchesCategory = selectedCategory === 'all' || 
        (selectedCategory === 'Fleisch' && recipe.ingredients.some(ing => ing.toLowerCase().includes('fleisch') || ing.toLowerCase().includes('hähnchen') || ing.toLowerCase().includes('hackfleisch'))) ||
        (selectedCategory === 'Vegetarisch' && !recipe.ingredients.some(ing => ing.toLowerCase().includes('fleisch') || ing.toLowerCase().includes('hähnchen') || ing.toLowerCase().includes('hackfleisch'))) ||
        (selectedCategory === 'Süß' && recipe.ingredients.some(ing => ing.toLowerCase().includes('zucker') || ing.toLowerCase().includes('honig') || ing.toLowerCase().includes('kuchen'))) ||
        (selectedCategory === 'Suppen' && recipe.ingredients.some(ing => ing.toLowerCase().includes('suppe') || ing.toLowerCase().includes('brühe')));
      
      return matchesSearch && matchesDifficulty && matchesCookingTime && matchesCategory;
    });
  }, [searchTerm, selectedDifficulty, selectedCookingTime, selectedCategory]);

  const sortedRecipes = useMemo(() => {
    return [...filteredRecipes].sort((a, b) => {
      const aMatches = a.ingredients.filter(ingredient =>
        availableIngredients.some(available => 
          ingredientMatches(ingredient, available)
        )
      ).length;
      
      const bMatches = b.ingredients.filter(ingredient =>
        availableIngredients.some(available => 
          ingredientMatches(ingredient, available)
        )
      ).length;

      // If we have highlighted ingredients, prioritize recipes that actually use them
      if (highlightedIngredients.length > 0) {
        const aUsesHighlighted = recipeUsesHighlightedIngredients(a);
        const bUsesHighlighted = recipeUsesHighlightedIngredients(b);

        // Prioritize recipes that actually use highlighted ingredients
        if (aUsesHighlighted && !bUsesHighlighted) return -1;
        if (!aUsesHighlighted && bUsesHighlighted) return 1;

        // Among recipes that use highlighted ingredients, sort by number of highlighted matches
        if (aUsesHighlighted && bUsesHighlighted) {
          const aHighlightedMatches = a.ingredients.filter(ingredient =>
            highlightedIngredients.some(highlighted => 
              ingredientMatches(ingredient, highlighted)
            )
          ).length;
          
          const bHighlightedMatches = b.ingredients.filter(ingredient =>
            highlightedIngredients.some(highlighted => 
              ingredientMatches(ingredient, highlighted)
            )
          ).length;

          if (bHighlightedMatches !== aHighlightedMatches) {
            return bHighlightedMatches - aHighlightedMatches;
          }
        }
      }
      
      // Sort based on selected criteria
      switch (sortBy) {
        case 'match':
          if (bMatches !== aMatches) {
            return bMatches - aMatches;
          }
          return a.cookingTime - b.cookingTime;
        case 'time':
          return a.cookingTime - b.cookingTime;
        case 'difficulty':
          const difficultyOrder = { 'easy': 1, 'medium': 2, 'hard': 3 };
          return difficultyOrder[a.difficulty] - difficultyOrder[b.difficulty];
        case 'name':
          return a.name.localeCompare(b.name);
        default:
          return 0;
      }
    });
  }, [filteredRecipes, availableIngredients, highlightedIngredients, sortBy]);

  const handleRecipeClick = (recipe: Recipe) => {
    setSelectedRecipe(recipe);
    setIsRecipeDialogOpen(true);
  };

  const handleAddMissingToShopping = (missingIngredients: string[]) => {
    console.log('🛒 Adding missing ingredients to shopping list:', missingIngredients);
    
    missingIngredients.forEach(ingredient => {
      // Extract quantity and name from ingredient string (e.g., "2 Bananen" -> quantity: "2", name: "Bananen")
      const match = ingredient.match(/^(\d+(?:[.,]\d+)?)\s*(\w+)?\s*(.+)$/);
      let quantity = '1';
      let unit = 'Stück';
      let name = ingredient;
      
      if (match) {
        quantity = match[1].replace(',', '.');
        unit = match[2] || 'Stück';
        name = match[3] || ingredient;
      }
      
      addToShopping({
        name: name,
        quantity: quantity,
        unit: unit,
        category: 'Sonstiges',
      });
    });

    // Show success message
    setShowSuccessMessage(true);
    setTimeout(() => setShowSuccessMessage(false), 3000);

    console.log('✅ Added missing ingredients to shopping list');
  };

  const clearAllFilters = () => {
    setSearchTerm('');
    setSelectedDifficulty('all');
    setSelectedCookingTime('all');
    setSelectedCategory('all');
    setSortBy('match');
  };

  const hasActiveFilters = searchTerm || selectedDifficulty !== 'all' || selectedCookingTime !== 'all' || selectedCategory !== 'all';

  // Get matching recipes count for highlighted ingredients
  const matchingRecipesForHighlighted = getMatchingRecipesForHighlighted();
  const hasMatchingRecipes = matchingRecipesForHighlighted.length > 0;

  return (
    <div className="h-full flex flex-col bg-gradient-to-br from-orange-50 to-red-50">
      <StatusBar />

      {/* Success Message */}
      {showSuccessMessage && (
        <div className="absolute top-16 left-4 right-4 z-50">
          <div className="bg-fridge-green-500 text-white px-4 py-3 rounded-2xl shadow-lg flex items-center space-x-3">
            <CheckCircle className="w-6 h-6" />
            <span className="font-semibold">Zutaten zur Einkaufsliste hinzugefügt!</span>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="px-4 py-2 bg-white/80 backdrop-blur-sm border-b border-white/20">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-fridge-navy-900 tracking-tight">Rezepte</h1>
            <p className="text-xs text-fridge-navy-600 font-medium">Basierend auf Ihren Vorräten • {sampleRecipes.length} Rezepte</p>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowAdvancedFilters(!showAdvancedFilters)}
            className={`rounded-xl border-2 shadow-md ${showAdvancedFilters ? 'bg-fridge-blue-100 border-fridge-blue-300' : 'border-fridge-blue-200 hover:border-fridge-blue-300'}`}
          >
            <Filter className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Highlighted Ingredients Banner - Verbessert */}
      {highlightedIngredients.length > 0 && (
        <div className="px-4 py-3 bg-gradient-to-r from-orange-100 to-red-100 border-b border-orange-200">
          <div className="flex items-start space-x-3">
            <div className="w-8 h-8 bg-orange-500 rounded-xl flex items-center justify-center flex-shrink-0 mt-0.5">
              <AlertTriangle className="w-4 h-4 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="font-bold text-orange-900 text-sm mb-1">
                🔥 Für bald ablaufende Zutaten
              </h3>
              <div className="flex flex-wrap gap-1 mb-2">
                {highlightedIngredients.map((ingredient, index) => (
                  <span
                    key={index}
                    className="px-2 py-0.5 bg-orange-200 text-orange-900 rounded-xl text-xs font-bold"
                  >
                    {ingredient}
                  </span>
                ))}
              </div>
              {hasMatchingRecipes ? (
                <p className="text-xs text-orange-700 font-medium">
                  ✅ {matchingRecipesForHighlighted.length} passende{matchingRecipesForHighlighted.length !== 1 ? '' : 's'} Rezept{matchingRecipesForHighlighted.length !== 1 ? 'e' : ''} gefunden
                </p>
              ) : (
                <p className="text-xs text-orange-700 font-medium">
                  ❌ Keine passenden Rezepte für diese Zutaten gefunden
                </p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Search */}
      <div className="px-4 py-2 bg-white/80 backdrop-blur-sm">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-fridge-navy-400 w-4 h-4" />
          <Input
            placeholder="Rezepte durchsuchen..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 h-10 rounded-xl border-2 border-fridge-blue-200 bg-white shadow-sm text-sm focus:border-fridge-blue-400"
          />
        </div>
      </div>

      {/* Advanced Filters */}
      {showAdvancedFilters && (
        <div className="px-4 py-3 bg-white/90 backdrop-blur-sm border-b border-white/20 space-y-3">
          {/* Quick Filters Row 1 */}
          <div className="flex space-x-2 overflow-x-auto pb-1">
            <Button
              size="sm"
              variant={selectedDifficulty === 'all' ? 'default' : 'outline'}
              onClick={() => setSelectedDifficulty('all')}
              className="rounded-xl px-3 py-1 text-xs whitespace-nowrap h-8 font-bold"
            >
              Alle Schwierigkeiten
            </Button>
            <Button
              size="sm"
              variant={selectedDifficulty === 'easy' ? 'default' : 'outline'}
              onClick={() => setSelectedDifficulty('easy')}
              className="rounded-xl px-3 py-1 text-xs whitespace-nowrap h-8 font-bold"
            >
              🟢 Einfach
            </Button>
            <Button
              size="sm"
              variant={selectedDifficulty === 'medium' ? 'default' : 'outline'}
              onClick={() => setSelectedDifficulty('medium')}
              className="rounded-xl px-3 py-1 text-xs whitespace-nowrap h-8 font-bold"
            >
              🟡 Mittel
            </Button>
            <Button
              size="sm"
              variant={selectedDifficulty === 'hard' ? 'default' : 'outline'}
              onClick={() => setSelectedDifficulty('hard')}
              className="rounded-xl px-3 py-1 text-xs whitespace-nowrap h-8 font-bold"
            >
              🔴 Schwer
            </Button>
          </div>

          {/* Quick Filters Row 2 */}
          <div className="flex space-x-2 overflow-x-auto pb-1">
            <Button
              size="sm"
              variant={selectedCookingTime === 'all' ? 'default' : 'outline'}
              onClick={() => setSelectedCookingTime('all')}
              className="rounded-xl px-3 py-1 text-xs whitespace-nowrap h-8 font-bold"
            >
              <Clock className="w-3 h-3 mr-1" />
              Alle Zeiten
            </Button>
            <Button
              size="sm"
              variant={selectedCookingTime === 'quick' ? 'default' : 'outline'}
              onClick={() => setSelectedCookingTime('quick')}
              className="rounded-xl px-3 py-1 text-xs whitespace-nowrap h-8 font-bold"
            >
              ⚡ ≤15 Min
            </Button>
            <Button
              size="sm"
              variant={selectedCookingTime === 'medium' ? 'default' : 'outline'}
              onClick={() => setSelectedCookingTime('medium')}
              className="rounded-xl px-3 py-1 text-xs whitespace-nowrap h-8 font-bold"
            >
              🕐 15-45 Min
            </Button>
            <Button
              size="sm"
              variant={selectedCookingTime === 'long' ? 'default' : 'outline'}
              onClick={() => setSelectedCookingTime('long')}
              className="rounded-xl px-3 py-1 text-xs whitespace-nowrap h-8 font-bold"
            >
              🕑 &gt;45 Min
            </Button>
          </div>

          {/* Category Filters */}
          <div className="flex space-x-2 overflow-x-auto pb-1">
            <Button
              size="sm"
              variant={selectedCategory === 'all' ? 'default' : 'outline'}
              onClick={() => setSelectedCategory('all')}
              className="rounded-xl px-3 py-1 text-xs whitespace-nowrap h-8 font-bold"
            >
              <Utensils className="w-3 h-3 mr-1" />
              Alle Kategorien
            </Button>
            <Button
              size="sm"
              variant={selectedCategory === 'Vegetarisch' ? 'default' : 'outline'}
              onClick={() => setSelectedCategory('Vegetarisch')}
              className="rounded-xl px-3 py-1 text-xs whitespace-nowrap h-8 font-bold"
            >
              🥬 Vegetarisch
            </Button>
            <Button
              size="sm"
              variant={selectedCategory === 'Fleisch' ? 'default' : 'outline'}
              onClick={() => setSelectedCategory('Fleisch')}
              className="rounded-xl px-3 py-1 text-xs whitespace-nowrap h-8 font-bold"
            >
              🥩 Fleisch
            </Button>
            <Button
              size="sm"
              variant={selectedCategory === 'Süß' ? 'default' : 'outline'}
              onClick={() => setSelectedCategory('Süß')}
              className="rounded-xl px-3 py-1 text-xs whitespace-nowrap h-8 font-bold"
            >
              🍰 Süß
            </Button>
            <Button
              size="sm"
              variant={selectedCategory === 'Suppen' ? 'default' : 'outline'}
              onClick={() => setSelectedCategory('Suppen')}
              className="rounded-xl px-3 py-1 text-xs whitespace-nowrap h-8 font-bold"
            >
              🍲 Suppen
            </Button>
          </div>

          {/* Sort Options */}
          <div className="flex items-center justify-between">
            <div className="flex space-x-2 overflow-x-auto">
              <span className="text-xs font-bold text-fridge-navy-700 flex items-center whitespace-nowrap">
                <Star className="w-3 h-3 mr-1" />
                Sortieren:
              </span>
              <Button
                size="sm"
                variant={sortBy === 'match' ? 'default' : 'outline'}
                onClick={() => setSortBy('match')}
                className="rounded-xl px-3 py-1 text-xs whitespace-nowrap h-7 font-bold"
              >
                Passend
              </Button>
              <Button
                size="sm"
                variant={sortBy === 'time' ? 'default' : 'outline'}
                onClick={() => setSortBy('time')}
                className="rounded-xl px-3 py-1 text-xs whitespace-nowrap h-7 font-bold"
              >
                Zeit
              </Button>
              <Button
                size="sm"
                variant={sortBy === 'difficulty' ? 'default' : 'outline'}
                onClick={() => setSortBy('difficulty')}
                className="rounded-xl px-3 py-1 text-xs whitespace-nowrap h-7 font-bold"
              >
                Schwierigkeit
              </Button>
              <Button
                size="sm"
                variant={sortBy === 'name' ? 'default' : 'outline'}
                onClick={() => setSortBy('name')}
                className="rounded-xl px-3 py-1 text-xs whitespace-nowrap h-7 font-bold"
              >
                Name
              </Button>
            </div>

            {hasActiveFilters && (
              <Button
                size="sm"
                variant="ghost"
                onClick={clearAllFilters}
                className="text-red-600 hover:text-red-700 hover:bg-red-50 rounded-xl px-2 py-1 text-xs font-bold"
              >
                <X className="w-3 h-3 mr-1" />
                Filter löschen
              </Button>
            )}
          </div>
        </div>
      )}

      {/* Available Ingredients */}
      {availableIngredients.length > 0 && (
        <div className="px-4 py-1 bg-fridge-green-100/60 backdrop-blur-sm">
          <div className="flex items-center space-x-2">
            <span className="text-xs font-bold text-fridge-green-900">✅ Verfügbar:</span>
            <div className="flex flex-wrap gap-1">
              {availableIngredients.slice(0, 3).map((ingredient, index) => (
                <span
                  key={index}
                  className="px-1.5 py-0.5 bg-fridge-green-200 text-fridge-green-900 rounded-lg text-xs font-bold"
                >
                  {ingredient}
                </span>
              ))}
              {availableIngredients.length > 3 && (
                <span className="px-1.5 py-0.5 bg-fridge-green-200 text-fridge-green-900 rounded-lg text-xs font-bold">
                  +{availableIngredients.length - 3}
                </span>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Results Summary */}
      {(hasActiveFilters || showAdvancedFilters) && (
        <div className="px-4 py-2 bg-fridge-blue-50/80 backdrop-blur-sm">
          <p className="text-sm font-semibold text-fridge-blue-900">
            📊 {sortedRecipes.length} von {sampleRecipes.length} Rezepten gefunden
            {hasActiveFilters && (
              <span className="ml-2 text-xs text-fridge-blue-700">
                (Filter aktiv)
              </span>
            )}
          </p>
        </div>
      )}

      {/* Recipes List */}
      <div className="flex-1 overflow-y-auto px-4 py-3">
        {sortedRecipes.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center py-12">
            <div className="w-24 h-24 bg-white/80 backdrop-blur-sm rounded-3xl flex items-center justify-center mb-6 shadow-lg">
              <ChefHat className="w-12 h-12 text-fridge-blue-400" />
            </div>
            <h3 className="text-xl font-bold text-fridge-navy-900 mb-2">
              Keine Rezepte gefunden
            </h3>
            <p className="text-fridge-navy-600 text-center px-6 leading-relaxed mb-4">
              {highlightedIngredients.length > 0 
                ? 'Für die ablaufenden Zutaten wurden keine passenden Rezepte gefunden. Versuchen Sie andere Filter oder schauen Sie nach allgemeinen Rezepten.'
                : hasActiveFilters 
                  ? 'Versuchen Sie andere Filter oder entfernen Sie einige Einschränkungen'
                  : 'Versuchen Sie andere Suchbegriffe oder fügen Sie mehr Produkte hinzu'
              }
            </p>
            {hasActiveFilters && (
              <Button
                onClick={clearAllFilters}
                variant="outline"
                className="rounded-2xl border-2 shadow-md border-fridge-blue-200 hover:border-fridge-blue-300"
              >
                <X className="w-4 h-4 mr-2" />
                Alle Filter entfernen
              </Button>
            )}
          </div>
        ) : (
          <div className="space-y-3 pb-3">
            {sortedRecipes.map((recipe) => (
              <RecipeCard
                key={recipe.id}
                recipe={recipe}
                availableIngredients={availableIngredients}
                onClick={handleRecipeClick}
              />
            ))}
          </div>
        )}
      </div>

      {/* Recipe Detail Dialog */}
      <RecipeDetailDialog
        isOpen={isRecipeDialogOpen}
        onClose={() => setIsRecipeDialogOpen(false)}
        recipe={selectedRecipe}
        availableIngredients={availableIngredients}
        onAddMissingToShopping={handleAddMissingToShopping}
      />
    </div>
  );
};
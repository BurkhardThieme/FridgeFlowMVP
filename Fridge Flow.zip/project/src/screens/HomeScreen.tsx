import React, { useState } from 'react';
import { FoodItemCard } from '../components/FoodItemCard';
import { AddItemDialog } from '../components/AddItemDialog';
import { ScanDialog } from '../components/ScanDialog';
import { ExpiringItemsDialog } from '../components/ExpiringItemsDialog';
import { ConsumeQuantityDialog } from '../components/ConsumeQuantityDialog';
import { StatusBar } from '../components/StatusBar';
import { Button } from '../components/ui/button';
import { useFoodInventory } from '../hooks/useFoodInventory';
import { useShoppingList } from '../hooks/useShoppingList';
import { FoodItem } from '../types';
import { Plus, Camera, AlertTriangle, Bell, ArrowUpDown } from 'lucide-react';

interface HomeScreenProps {
  onNavigateToRecipes: (ingredients: string[]) => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({ onNavigateToRecipes }) => {
  const { items, addItem, removeItem, consumeQuantity, getExpiringSoonItems, isLoaded } = useFoodInventory();
  const { addItem: addToShopping } = useShoppingList();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isScanDialogOpen, setIsScanDialogOpen] = useState(false);
  const [isExpiringDialogOpen, setIsExpiringDialogOpen] = useState(false);
  const [isConsumeDialogOpen, setIsConsumeDialogOpen] = useState(false);
  const [consumingItem, setConsumingItem] = useState<FoodItem | null>(null);
  const [isExpiringAlertDismissed, setIsExpiringAlertDismissed] = useState(false);
  const [sortBy, setSortBy] = useState<'expiry' | 'name' | 'category'>('expiry');

  const expiringSoonItems = getExpiringSoonItems();

  const handleAddToShopping = (item: FoodItem) => {
    console.log('🛒 Adding item to shopping list:', item.name);
    addToShopping({
      name: item.name,
      quantity: item.quantity,
      unit: item.unit,
      category: item.category,
    });
  };

  const handleScanComplete = (scannedItems: any[]) => {
    console.log('📷 Processing scanned items:', scannedItems);
    scannedItems.forEach(item => {
      console.log('📷➕ Adding scanned item:', item);
      addItem(item);
    });
  };

  const handleConsume = (item: FoodItem) => {
    setConsumingItem(item);
    setIsConsumeDialogOpen(true);
  };

  const handleCloseConsumeDialog = () => {
    setIsConsumeDialogOpen(false);
    setConsumingItem(null);
  };

  const handleExpiringItemsClick = () => {
    setIsExpiringDialogOpen(true);
    // Dismiss the alert banner after first click
    setIsExpiringAlertDismissed(true);
  };

  const handleBellClick = () => {
    // Bell click always opens the expiring items dialog
    setIsExpiringDialogOpen(true);
  };

  const handleGoToRecipesFromExpiring = (ingredients: string[]) => {
    onNavigateToRecipes(ingredients);
  };

  const handleConsumeQuantity = (id: string, consumedQuantity: number, newQuantity: string) => {
    console.log('☕ Handling consume quantity:', { id, consumedQuantity, newQuantity });
    consumeQuantity(id, consumedQuantity, newQuantity);
  };

  // Sort items based on selected criteria
  const getSortedItems = () => {
    return [...items].sort((a, b) => {
      switch (sortBy) {
        case 'expiry':
          return new Date(a.expiryDate).getTime() - new Date(b.expiryDate).getTime();
        case 'name':
          return a.name.localeCompare(b.name);
        case 'category':
          if (a.category !== b.category) {
            return a.category.localeCompare(b.category);
          }
          return a.name.localeCompare(b.name);
        default:
          return 0;
      }
    });
  };

  const getSortLabel = () => {
    switch (sortBy) {
      case 'expiry': return 'Ablaufdatum';
      case 'name': return 'Name';
      case 'category': return 'Kategorie';
      default: return 'Sortierung';
    }
  };

  const cycleSorting = () => {
    const sortOptions: ('expiry' | 'name' | 'category')[] = ['expiry', 'name', 'category'];
    const currentIndex = sortOptions.indexOf(sortBy);
    const nextIndex = (currentIndex + 1) % sortOptions.length;
    setSortBy(sortOptions[nextIndex]);
  };

  // Show loading state while data is being loaded
  if (!isLoaded) {
    return (
      <div className="h-full flex flex-col bg-gradient-to-br from-fridge-blue-50 to-fridge-green-50">
        <StatusBar />
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <div className="w-12 h-12 border-4 border-fridge-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-fridge-navy-600 font-medium">Lade Vorräte...</p>
          </div>
        </div>
      </div>
    );
  }

  const sortedItems = getSortedItems();

  return (
    <div className="h-full flex flex-col bg-gradient-to-br from-fridge-blue-50 to-fridge-green-50">
      <StatusBar />

      {/* Kompakter Header */}
      <div className="px-4 py-3 bg-white/80 backdrop-blur-sm border-b border-white/20">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h1 className="text-2xl font-bold text-fridge-navy-700 tracking-tight">Meine Vorräte</h1>
            <p className="text-xs text-fridge-navy-600 font-medium">{items.length} Produkte</p>
          </div>
          <button
            onClick={handleBellClick}
            className="relative p-2 rounded-xl bg-white shadow-md hover:shadow-lg active:scale-95 transition-all duration-200"
          >
            <Bell className="w-5 h-5 text-fridge-navy-700" />
            {expiringSoonItems.length > 0 && (
              <div className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full flex items-center justify-center shadow-lg">
                <span className="text-xs text-white font-bold">{expiringSoonItems.length}</span>
              </div>
            )}
          </button>
        </div>

        {/* Kompakte Expiring Soon Alert */}
        {expiringSoonItems.length > 0 && !isExpiringAlertDismissed && (
          <button
            onClick={handleExpiringItemsClick}
            className="w-full bg-gradient-to-r from-orange-100 to-red-100 border border-orange-200 rounded-xl p-3 mb-3 active:scale-98 transition-all duration-200 shadow-sm"
          >
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-orange-500 rounded-xl flex items-center justify-center">
                <AlertTriangle className="w-4 h-4 text-white" />
              </div>
              <div className="flex-1 text-left">
                <h3 className="font-bold text-orange-900 text-sm">
                  {expiringSoonItems.length} Produkt{expiringSoonItems.length !== 1 ? 'e' : ''} läuft bald ab
                </h3>
              </div>
              <div className="w-6 h-6 bg-orange-500 rounded-full flex items-center justify-center">
                <span className="text-xs text-white font-bold">{expiringSoonItems.length}</span>
              </div>
            </div>
          </button>
        )}

        {/* Kompakte Action Buttons */}
        <div className="flex space-x-3">
          <Button
            onClick={() => setIsScanDialogOpen(true)}
            className="flex-1 h-12 bg-gradient-to-r from-fridge-blue-600 to-fridge-blue-700 hover:from-fridge-blue-700 hover:to-fridge-blue-800 rounded-xl flex items-center justify-center space-x-2 shadow-md hover:shadow-lg active:scale-98 transition-all duration-200"
          >
            <Camera className="w-5 h-5" />
            <span className="font-bold">Scannen</span>
          </Button>
          
          <Button
            onClick={() => setIsAddDialogOpen(true)}
            variant="outline"
            className="flex-1 h-12 border-2 border-fridge-blue-300 bg-white/80 backdrop-blur-sm rounded-xl flex items-center justify-center space-x-2 shadow-md hover:shadow-lg active:scale-98 transition-all duration-200 hover:border-fridge-blue-400"
          >
            <Plus className="w-5 h-5" />
            <span className="font-bold">Hinzufügen</span>
          </Button>
        </div>
      </div>

      {/* Kompakte Sortierung */}
      {items.length > 0 && (
        <div className="px-4 py-2 bg-white/60 backdrop-blur-sm border-b border-white/20">
          <button
            onClick={cycleSorting}
            className="flex items-center space-x-2 px-3 py-1.5 bg-white/80 rounded-xl shadow-sm border border-fridge-blue-200 hover:bg-white active:scale-98 transition-all duration-200 hover:border-fridge-blue-300"
          >
            <ArrowUpDown className="w-3 h-3 text-fridge-navy-600" />
            <span className="text-xs font-semibold text-fridge-navy-700">
              {getSortLabel()}
            </span>
          </button>
        </div>
      )}

      {/* Food Items List - Mehr Platz */}
      <div className="flex-1 overflow-y-auto px-4 py-3">
        {items.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center py-12">
            <div className="w-24 h-24 bg-white/80 backdrop-blur-sm rounded-3xl flex items-center justify-center mb-6 shadow-lg">
              <Camera className="w-12 h-12 text-fridge-blue-400" />
            </div>
            <h3 className="text-xl font-bold text-fridge-navy-900 mb-2">
              Noch keine Produkte
            </h3>
            <p className="text-fridge-navy-600 text-center mb-8 px-6 leading-relaxed">
              Scannen Sie einen Kassenbon oder fügen Sie Produkte manuell hinzu
            </p>
            <Button 
              onClick={() => setIsScanDialogOpen(true)}
              className="bg-gradient-to-r from-fridge-blue-600 to-fridge-blue-700 hover:from-fridge-blue-700 hover:to-fridge-blue-800 rounded-2xl px-8 py-4 shadow-lg hover:shadow-xl active:scale-98 transition-all duration-200"
            >
              <Camera className="w-5 h-5 mr-2" />
              <span className="font-bold">Ersten Scan starten</span>
            </Button>
          </div>
        ) : (
          <div className="space-y-3 pb-3">
            {sortedItems.map((item) => (
              <FoodItemCard
                key={item.id}
                item={item}
                onDelete={removeItem}
                onAddToShopping={handleAddToShopping}
                onConsume={handleConsume}
              />
            ))}
          </div>
        )}
      </div>

      {/* Dialogs */}
      <AddItemDialog
        isOpen={isAddDialogOpen}
        onClose={() => setIsAddDialogOpen(false)}
        onAdd={addItem}
      />

      <ScanDialog
        isOpen={isScanDialogOpen}
        onClose={() => setIsScanDialogOpen(false)}
        onScanComplete={handleScanComplete}
      />

      <ExpiringItemsDialog
        isOpen={isExpiringDialogOpen}
        onClose={() => setIsExpiringDialogOpen(false)}
        items={expiringSoonItems}
        onGoToRecipes={handleGoToRecipesFromExpiring}
      />

      <ConsumeQuantityDialog
        isOpen={isConsumeDialogOpen}
        onClose={handleCloseConsumeDialog}
        item={consumingItem}
        onConsume={handleConsumeQuantity}
      />
    </div>
  );
};
import React, { useState } from 'react';
import { ShoppingListItem } from '../components/ShoppingListItem';
import { AddItemDialog } from '../components/AddItemDialog';
import { FoodAutocomplete } from '../components/FoodAutocomplete';
import { StatusBar } from '../components/StatusBar';
import { Button } from '../components/ui/button';
import { useShoppingList } from '../hooks/useShoppingList';
import { getFoodSuggestion } from '../data/foodDatabase';
import { Plus, ShoppingCart, Trash2 } from 'lucide-react';

export const ShoppingScreen: React.FC = () => {
  const { items, addItem, toggleItem, removeItem, clearCompleted, isLoaded } = useShoppingList();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [quickAddName, setQuickAddName] = useState('');

  const completedItems = items.filter(item => item.isCompleted);
  const pendingItems = items.filter(item => !item.isCompleted);

  const handleQuickAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (quickAddName.trim()) {
      console.log('🛒⚡ Quick adding item:', quickAddName.trim());
      
      // Try to get suggestion for better defaults
      const suggestion = getFoodSuggestion(quickAddName.trim());
      
      addItem({
        name: quickAddName.trim(),
        quantity: suggestion?.defaultQuantity || '1',
        unit: suggestion?.defaultUnit || 'Stück',
        category: suggestion?.category || 'Sonstiges',
      });
      setQuickAddName('');
    }
  };

  const handleSuggestionSelect = (suggestion: any) => {
    console.log('🛒🤖 Adding suggested item:', suggestion.name);
    addItem({
      name: suggestion.name,
      quantity: suggestion.defaultQuantity,
      unit: suggestion.defaultUnit,
      category: suggestion.category,
    });
    setQuickAddName('');
  };

  const handleAddFromDialog = (item: any) => {
    console.log('🛒📝 Adding item from dialog:', item);
    addItem(item);
  };

  // Show loading state while data is being loaded
  if (!isLoaded) {
    return (
      <div className="h-full flex flex-col bg-gradient-to-br from-fridge-blue-50 to-fridge-green-50">
        <StatusBar />
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <div className="w-12 h-12 border-4 border-fridge-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-fridge-navy-600 font-medium">Lade Einkaufsliste...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col bg-gradient-to-br from-fridge-blue-50 to-fridge-green-50">
      <StatusBar />

      {/* Header */}
      <div className="px-6 py-6 bg-white/80 backdrop-blur-sm border-b border-white/20">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-fridge-navy-900 tracking-tight">Einkaufsliste</h1>
            <p className="text-sm text-fridge-navy-600 font-medium">{pendingItems.length} offene Artikel</p>
          </div>
          {completedItems.length > 0 && (
            <Button
              variant="outline"
              size="sm"
              onClick={clearCompleted}
              className="text-red-600 hover:text-red-700 rounded-2xl border-2 border-red-200 bg-red-50 hover:bg-red-100 shadow-md"
            >
              <Trash2 className="w-5 h-5" />
            </Button>
          )}
        </div>
      </div>

      {/* Smart Quick Add */}
      <div className="px-6 py-4 bg-white/80 backdrop-blur-sm border-b border-white/20">
        <form onSubmit={handleQuickAdd} className="flex space-x-3">
          <div className="flex-1">
            <FoodAutocomplete
              value={quickAddName}
              onChange={setQuickAddName}
              onSuggestionSelect={handleSuggestionSelect}
              placeholder="Artikel hinzufügen..."
              className="h-14 rounded-2xl border-2 border-fridge-blue-200 bg-white shadow-sm text-base focus:border-fridge-blue-400"
            />
          </div>
          <Button 
            type="submit" 
            size="sm"
            className="h-14 w-14 rounded-2xl bg-gradient-to-r from-fridge-blue-600 to-fridge-blue-700 hover:from-fridge-blue-700 hover:to-fridge-blue-800 shadow-lg"
          >
            <Plus className="w-6 h-6" />
          </Button>
        </form>
      </div>

      {/* Shopping List */}
      <div className="flex-1 overflow-y-auto">
        {items.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center py-16 px-6">
            <div className="w-32 h-32 bg-white/80 backdrop-blur-sm rounded-3xl flex items-center justify-center mb-8 shadow-lg">
              <ShoppingCart className="w-16 h-16 text-fridge-blue-400" />
            </div>
            <h3 className="text-2xl font-bold text-fridge-navy-900 mb-3">
              Einkaufsliste ist leer
            </h3>
            <p className="text-fridge-navy-600 text-center mb-10 leading-relaxed">
              Fügen Sie Artikel hinzu, die Sie kaufen möchten
            </p>
            <div className="text-center">
              <p className="text-fridge-navy-500 text-sm mb-4">
                Tipp: Nutzen Sie die intelligente Eingabe oben
              </p>
              <div className="inline-flex items-center px-4 py-2 bg-fridge-blue-100 rounded-2xl">
                <span className="text-fridge-blue-700 font-semibold">🤖 Automatische Vorschläge & Bilder</span>
              </div>
            </div>
          </div>
        ) : (
          <div className="px-6 py-4 space-y-6">
            {/* Pending Items */}
            {pendingItems.length > 0 && (
              <div>
                <h2 className="text-xl font-bold text-fridge-navy-900 mb-4">
                  📝 Zu kaufen ({pendingItems.length})
                </h2>
                <div className="space-y-3">
                  {pendingItems.map((item) => (
                    <ShoppingListItem
                      key={item.id}
                      item={item}
                      onToggle={toggleItem}
                      onRemove={removeItem}
                    />
                  ))}
                </div>
              </div>
            )}

            {/* Completed Items */}
            {completedItems.length > 0 && (
              <div>
                <h2 className="text-xl font-bold text-fridge-navy-900 mb-4">
                  ✅ Erledigt ({completedItems.length})
                </h2>
                <div className="space-y-3">
                  {completedItems.map((item) => (
                    <ShoppingListItem
                      key={item.id}
                      item={item}
                      onToggle={toggleItem}
                      onRemove={removeItem}
                    />
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Add Item Dialog - Nur noch für spezielle Fälle über Rezepte */}
      <AddItemDialog
        isOpen={isAddDialogOpen}
        onClose={() => setIsAddDialogOpen(false)}
        onAdd={handleAddFromDialog}
      />
    </div>
  );
};
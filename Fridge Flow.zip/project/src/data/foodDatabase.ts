// Comprehensive food database with images and metadata
export interface FoodSuggestion {
  name: string;
  category: string;
  defaultUnit: string;
  defaultQuantity: string;
  defaultExpiryDays: number;
  image: string;
  keywords: string[];
  variations: string[];
}

export const foodDatabase: FoodSuggestion[] = [
  // Obst
  {
    name: 'Äpfel',
    category: 'Obst',
    defaultUnit: 'kg',
    defaultQuantity: '1',
    defaultExpiryDays: 14,
    image: 'https://images.pexels.com/photos/102104/pexels-photo-102104.jpeg?auto=compress&cs=tinysrgb&w=400',
    keywords: ['apfel', 'äpfel', 'apple'],
    variations: ['Apfel', 'Äpfel', 'Granny Smith', 'Gala']
  },
  {
    name: 'Bananen',
    category: 'Obst',
    defaultUnit: 'kg',
    defaultQuantity: '1',
    defaultExpiryDays: 7,
    image: 'https://images.pexels.com/photos/2872755/pexels-photo-2872755.jpeg?auto=compress&cs=tinysrgb&w=400',
    keywords: ['banane', 'bananen', 'banana'],
    variations: ['Banane', 'Bananen']
  },
  {
    name: 'Zitronen',
    category: 'Obst',
    defaultUnit: 'Stück',
    defaultQuantity: '4',
    defaultExpiryDays: 21,
    image: 'https://images.pexels.com/photos/1414130/pexels-photo-1414130.jpeg?auto=compress&cs=tinysrgb&w=400',
    keywords: ['zitrone', 'zitronen', 'lemon'],
    variations: ['Zitrone', 'Zitronen']
  },
  {
    name: 'Orangen',
    category: 'Obst',
    defaultUnit: 'kg',
    defaultQuantity: '1',
    defaultExpiryDays: 14,
    image: 'https://images.pexels.com/photos/161559/background-bitter-breakfast-bright-161559.jpeg?auto=compress&cs=tinysrgb&w=400',
    keywords: ['orange', 'orangen', 'apfelsine'],
    variations: ['Orange', 'Orangen', 'Apfelsine']
  },

  // Gemüse
  {
    name: 'Tomaten',
    category: 'Gemüse',
    defaultUnit: 'kg',
    defaultQuantity: '0.5',
    defaultExpiryDays: 7,
    image: 'https://images.pexels.com/photos/533280/pexels-photo-533280.jpeg?auto=compress&cs=tinysrgb&w=400',
    keywords: ['tomate', 'tomaten', 'tomato'],
    variations: ['Tomate', 'Tomaten', 'Cherrytomaten', 'Cocktailtomaten']
  },
  {
    name: 'Kirschtomaten',
    category: 'Gemüse',
    defaultUnit: 'g',
    defaultQuantity: '300',
    defaultExpiryDays: 7,
    image: 'https://images.pexels.com/photos/533280/pexels-photo-533280.jpeg?auto=compress&cs=tinysrgb&w=400',
    keywords: ['kirschtomate', 'kirschtomaten', 'cherry tomato', 'cocktailtomate'],
    variations: ['Kirschtomate', 'Kirschtomaten', 'Cocktailtomaten', 'Cherry Tomaten']
  },
  {
    name: 'Karotten',
    category: 'Gemüse',
    defaultUnit: 'kg',
    defaultQuantity: '1',
    defaultExpiryDays: 21,
    image: 'https://images.pexels.com/photos/143133/pexels-photo-143133.jpeg?auto=compress&cs=tinysrgb&w=400',
    keywords: ['karotte', 'karotten', 'möhre', 'möhren', 'carrot'],
    variations: ['Karotte', 'Karotten', 'Möhre', 'Möhren']
  },
  {
    name: 'Zwiebeln',
    category: 'Gemüse',
    defaultUnit: 'kg',
    defaultQuantity: '1',
    defaultExpiryDays: 30,
    image: 'https://images.pexels.com/photos/533342/pexels-photo-533342.jpeg?auto=compress&cs=tinysrgb&w=400',
    keywords: ['zwiebel', 'zwiebeln', 'onion'],
    variations: ['Zwiebel', 'Zwiebeln', 'Gemüsezwiebel']
  },
  {
    name: 'Paprika',
    category: 'Gemüse',
    defaultUnit: 'Stück',
    defaultQuantity: '3',
    defaultExpiryDays: 10,
    image: 'https://images.pexels.com/photos/594137/pexels-photo-594137.jpeg?auto=compress&cs=tinysrgb&w=400',
    keywords: ['paprika', 'paprikaschote', 'pepper'],
    variations: ['Paprika', 'Paprikaschote', 'Rote Paprika', 'Gelbe Paprika']
  },
  {
    name: 'Gurken',
    category: 'Gemüse',
    defaultUnit: 'Stück',
    defaultQuantity: '2',
    defaultExpiryDays: 7,
    image: 'https://images.pexels.com/photos/37528/cucumber-salad-food-healthy-37528.jpeg?auto=compress&cs=tinysrgb&w=400',
    keywords: ['gurke', 'gurken', 'cucumber'],
    variations: ['Gurke', 'Gurken', 'Salatgurke']
  },
  {
    name: 'Salat',
    category: 'Gemüse',
    defaultUnit: 'Stück',
    defaultQuantity: '1',
    defaultExpiryDays: 5,
    image: 'https://images.pexels.com/photos/1352199/pexels-photo-1352199.jpeg?auto=compress&cs=tinysrgb&w=400',
    keywords: ['salat', 'kopfsalat', 'lettuce'],
    variations: ['Salat', 'Kopfsalat', 'Eisbergsalat', 'Rucola']
  },

  // Milchprodukte - KORRIGIERTES JOGHURT-BILD
  {
    name: 'Milch',
    category: 'Milchprodukte',
    defaultUnit: 'L',
    defaultQuantity: '1',
    defaultExpiryDays: 5,
    image: 'https://images.pexels.com/photos/248412/pexels-photo-248412.jpeg?auto=compress&cs=tinysrgb&w=400',
    keywords: ['milch', 'milk', 'vollmilch'],
    variations: ['Milch', 'Vollmilch', 'Fettarme Milch', 'H-Milch']
  },
  {
    name: 'Joghurt',
    category: 'Milchprodukte',
    defaultUnit: 'g',
    defaultQuantity: '500',
    defaultExpiryDays: 10,
    image: 'https://images.pexels.com/photos/1435735/pexels-photo-1435735.jpeg?auto=compress&cs=tinysrgb&w=400',
    keywords: ['joghurt', 'yogurt', 'naturjoghurt'],
    variations: ['Joghurt', 'Naturjoghurt', 'Griechischer Joghurt']
  },
  {
    name: 'Käse',
    category: 'Milchprodukte',
    defaultUnit: 'g',
    defaultQuantity: '200',
    defaultExpiryDays: 14,
    image: 'https://images.pexels.com/photos/773253/pexels-photo-773253.jpeg?auto=compress&cs=tinysrgb&w=400',
    keywords: ['käse', 'cheese', 'gouda'],
    variations: ['Käse', 'Gouda', 'Emmentaler', 'Mozzarella']
  },
  {
    name: 'Feta',
    category: 'Milchprodukte',
    defaultUnit: 'g',
    defaultQuantity: '200',
    defaultExpiryDays: 14,
    image: 'https://images.pexels.com/photos/1213710/pexels-photo-1213710.jpeg?auto=compress&cs=tinysrgb&w=400',
    keywords: ['feta', 'fetakäse', 'schafskäse', 'griechischer käse'],
    variations: ['Feta', 'Fetakäse', 'Schafskäse', 'Griechischer Käse']
  },
  {
    name: 'Mozzarella',
    category: 'Milchprodukte',
    defaultUnit: 'g',
    defaultQuantity: '200',
    defaultExpiryDays: 7,
    image: 'https://images.pexels.com/photos/4033328/pexels-photo-4033328.jpeg?auto=compress&cs=tinysrgb&w=400',
    keywords: ['mozzarella', 'büffelmozzarella', 'italienischer käse'],
    variations: ['Mozzarella', 'Büffelmozzarella', 'Mozzarella di Bufala']
  },
  {
    name: 'Butter',
    category: 'Milchprodukte',
    defaultUnit: 'g',
    defaultQuantity: '250',
    defaultExpiryDays: 21,
    image: 'https://images.pexels.com/photos/479643/pexels-photo-479643.jpeg?auto=compress&cs=tinysrgb&w=400',
    keywords: ['butter', 'margarine'],
    variations: ['Butter', 'Margarine']
  },
  {
    name: 'Eier',
    category: 'Milchprodukte',
    defaultUnit: 'Stück',
    defaultQuantity: '12',
    defaultExpiryDays: 28,
    image: 'https://images.pexels.com/photos/162712/egg-white-food-protein-162712.jpeg?auto=compress&cs=tinysrgb&w=400',
    keywords: ['ei', 'eier', 'egg'],
    variations: ['Ei', 'Eier', 'Bio-Eier']
  },

  // Fleisch
  {
    name: 'Hähnchenbrust',
    category: 'Fleisch',
    defaultUnit: 'g',
    defaultQuantity: '500',
    defaultExpiryDays: 3,
    image: 'https://images.pexels.com/photos/616354/pexels-photo-616354.jpeg?auto=compress&cs=tinysrgb&w=400',
    keywords: ['hähnchen', 'hühnchen', 'chicken', 'geflügel'],
    variations: ['Hähnchen', 'Hähnchenbrust', 'Hühnchen', 'Hühnerfilet']
  },
  {
    name: 'Hackfleisch',
    category: 'Fleisch',
    defaultUnit: 'g',
    defaultQuantity: '500',
    defaultExpiryDays: 2,
    image: 'https://images.pexels.com/photos/2338407/pexels-photo-2338407.jpeg?auto=compress&cs=tinysrgb&w=400',
    keywords: ['hackfleisch', 'hack', 'rinderhack'],
    variations: ['Hackfleisch', 'Rinderhack', 'Schweinehack']
  },

  // Getreide
  {
    name: 'Brot',
    category: 'Getreide',
    defaultUnit: 'Stück',
    defaultQuantity: '1',
    defaultExpiryDays: 4,
    image: 'https://images.pexels.com/photos/209206/pexels-photo-209206.jpeg?auto=compress&cs=tinysrgb&w=400',
    keywords: ['brot', 'bread', 'vollkornbrot'],
    variations: ['Brot', 'Vollkornbrot', 'Weißbrot', 'Schwarzbrot']
  },
  {
    name: 'Nudeln',
    category: 'Getreide',
    defaultUnit: 'g',
    defaultQuantity: '500',
    defaultExpiryDays: 730,
    image: 'https://images.pexels.com/photos/1437267/pexels-photo-1437267.jpeg?auto=compress&cs=tinysrgb&w=400',
    keywords: ['nudeln', 'pasta', 'spaghetti'],
    variations: ['Nudeln', 'Pasta', 'Spaghetti', 'Penne']
  },
  {
    name: 'Reis',
    category: 'Getreide',
    defaultUnit: 'kg',
    defaultQuantity: '1',
    defaultExpiryDays: 730,
    image: 'https://images.pexels.com/photos/723198/pexels-photo-723198.jpeg?auto=compress&cs=tinysrgb&w=400',
    keywords: ['reis', 'rice', 'basmati'],
    variations: ['Reis', 'Basmati Reis', 'Jasmin Reis', 'Vollkornreis']
  },

  // Sonstiges
  {
    name: 'Olivenöl',
    category: 'Sonstiges',
    defaultUnit: 'ml',
    defaultQuantity: '500',
    defaultExpiryDays: 365,
    image: 'https://images.pexels.com/photos/33783/olive-oil-salad-dressing-cooking-olive.jpg?auto=compress&cs=tinysrgb&w=400',
    keywords: ['olivenöl', 'öl', 'oil'],
    variations: ['Olivenöl', 'Öl', 'Sonnenblumenöl']
  },
  {
    name: 'Salz',
    category: 'Gewürze',
    defaultUnit: 'g',
    defaultQuantity: '500',
    defaultExpiryDays: 1095,
    image: 'https://images.pexels.com/photos/1340116/pexels-photo-1340116.jpeg?auto=compress&cs=tinysrgb&w=400',
    keywords: ['salz', 'salt', 'meersalz'],
    variations: ['Salz', 'Meersalz', 'Steinsalz']
  },
  {
    name: 'Zucker',
    category: 'Sonstiges',
    defaultUnit: 'kg',
    defaultQuantity: '1',
    defaultExpiryDays: 730,
    image: 'https://images.pexels.com/photos/1340116/pexels-photo-1340116.jpeg?auto=compress&cs=tinysrgb&w=400',
    keywords: ['zucker', 'sugar', 'rohrzucker'],
    variations: ['Zucker', 'Rohrzucker', 'Puderzucker']
  }
];

// Helper function to search for food suggestions
export const searchFoodSuggestions = (query: string, limit: number = 5): FoodSuggestion[] => {
  if (!query || query.length < 2) return [];
  
  const normalizedQuery = query.toLowerCase().trim();
  
  const matches = foodDatabase.filter(food => {
    // Check name
    if (food.name.toLowerCase().includes(normalizedQuery)) return true;
    
    // Check keywords
    if (food.keywords.some(keyword => keyword.includes(normalizedQuery))) return true;
    
    // Check variations
    if (food.variations.some(variation => variation.toLowerCase().includes(normalizedQuery))) return true;
    
    return false;
  });

  // Sort by relevance (exact matches first, then partial matches)
  return matches
    .sort((a, b) => {
      const aExact = a.name.toLowerCase().startsWith(normalizedQuery) ? 1 : 0;
      const bExact = b.name.toLowerCase().startsWith(normalizedQuery) ? 1 : 0;
      
      if (aExact !== bExact) return bExact - aExact;
      
      return a.name.localeCompare(b.name);
    })
    .slice(0, limit);
};

// Helper function to get food suggestion by name
export const getFoodSuggestion = (name: string): FoodSuggestion | null => {
  const normalizedName = name.toLowerCase().trim();
  
  return foodDatabase.find(food => {
    if (food.name.toLowerCase() === normalizedName) return true;
    if (food.keywords.includes(normalizedName)) return true;
    if (food.variations.some(variation => variation.toLowerCase() === normalizedName)) return true;
    return false;
  }) || null;
};
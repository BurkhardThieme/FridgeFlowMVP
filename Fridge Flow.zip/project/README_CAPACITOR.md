# Food Inventory App - Native Mobile Setup

Diese Anleitung zeigt Ihnen, wie Sie die Food Inventory App als native Android und iOS App erstellen.

## Voraussetzungen

### Für Android:
- **Android Studio** (neueste Version)
- **Java Development Kit (JDK) 17** oder höher
- **Android SDK** (über Android Studio)

### Für iOS (nur auf Mac):
- **Xcode 14** oder höher
- **iOS 16 SDK** oder höher
- **CocoaPods** (`sudo gem install cocoapods`)

## Setup-Schritte

### 1. Abhängigkeiten installieren
```bash
npm install
```

### 2. App für Produktion bauen
```bash
npm run build
```

### 3. Capacitor initialisieren
```bash
npx cap init
```

### 4. Plattformen hinzufügen

**Android:**
```bash
npm run cap:add:android
```

**iOS (nur auf Mac):**
```bash
npm run cap:add:ios
```

### 5. Assets synchronisieren
```bash
npm run cap:sync
```

## Entwicklung

### Android entwickeln
```bash
# Android Studio öffnen
npm run cap:open:android

# Oder direkt auf Gerät/Emulator ausführen
npm run cap:run:android
```

### iOS entwickeln (nur auf Mac)
```bash
# Xcode öffnen
npm run cap:open:ios

# Oder direkt auf Gerät/Simulator ausführen
npm run cap:run:ios
```

## Nach Code-Änderungen

Wenn Sie Änderungen am Web-Code vornehmen:

```bash
npm run build:mobile
```

Dies baut die App neu und synchronisiert alle Änderungen mit den nativen Projekten.

## App-Features

### Native Funktionen:
- ✅ **Kamera-Zugriff** für Kassenbon-Scanning
- ✅ **Galerie-Zugriff** für Bild-Upload
- ✅ **Haptisches Feedback** bei Interaktionen
- ✅ **Status Bar** Anpassung
- ✅ **Splash Screen** beim App-Start
- ✅ **Offline-Speicherung** der Daten

### Plattform-spezifische Anpassungen:
- **Android**: Material Design Komponenten
- **iOS**: Native iOS Look & Feel
- **Web**: Progressive Web App (PWA) Fallback

## App Store Deployment

### Android (Google Play Store):
1. In Android Studio: `Build > Generate Signed Bundle/APK`
2. Wählen Sie "Android App Bundle"
3. Erstellen Sie einen Signing Key
4. Laden Sie die `.aab` Datei in die Google Play Console hoch

### iOS (Apple App Store):
1. In Xcode: `Product > Archive`
2. Verwenden Sie den Organizer zum Upload
3. Laden Sie die App über App Store Connect hoch

## Troubleshooting

### Android Studio Probleme:
- Stellen Sie sicher, dass JAVA_HOME korrekt gesetzt ist
- Aktualisieren Sie Android SDK Tools
- Löschen Sie `android/` Ordner und führen Sie `cap add android` erneut aus

### iOS/Xcode Probleme:
- Führen Sie `pod install` im `ios/App` Ordner aus
- Aktualisieren Sie CocoaPods: `pod repo update`
- Löschen Sie `ios/` Ordner und führen Sie `cap add ios` erneut aus

### Allgemeine Probleme:
- Löschen Sie `node_modules` und führen Sie `npm install` erneut aus
- Stellen Sie sicher, dass alle Capacitor Plugins aktuell sind
- Prüfen Sie die Capacitor Dokumentation: https://capacitorjs.com/docs

## Nützliche Befehle

```bash
# Capacitor Doctor (Probleme diagnostizieren)
npx cap doctor

# Plugins auflisten
npx cap ls

# Capacitor aktualisieren
npm install @capacitor/cli@latest @capacitor/core@latest

# Native Projekte neu erstellen
npx cap sync --deployment
```

## Support

Bei Problemen:
1. Prüfen Sie die Capacitor Dokumentation
2. Schauen Sie in die Android Studio / Xcode Logs
3. Verwenden Sie `npx cap doctor` zur Diagnose